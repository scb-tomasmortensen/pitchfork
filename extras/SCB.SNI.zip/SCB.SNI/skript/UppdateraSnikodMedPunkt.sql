--Uppdatera TA-tabellerna med 1 nyckel


 exec sp_Insert_SniKod_Dot  'TA_SNI2007UnderGrupp', 'AllmanText','SNI2007UnderGrupp',1 
 exec sp_Insert_SniKod_Dot  'TA_SNI2007HuvudGrupp', 'AllmanText','SNI2007HuvudGrupp',1
 exec sp_Insert_SniKod_Dot  'TA_SNI2007Grupp', 'AllmanText','SNI2007Grupp',1
 exec sp_Insert_SniKod_Dot  'TA_SNI2007DetaljGrupp', 'AllmanText','SNI2007DetaljGrupp',1
 exec sp_Insert_SniKod_Dot  'TA_SNI2007Avdelning', 'AllmanText','SNI2007Avdelning',1   
 
 
exec sp_Insert_SniKod_Dot  'TA_SNI2002UnderGrupp', 'AllmanText','SNI2002UnderGrupp',1

exec sp_Insert_SniKod_Dot  'TA_SNI2002UnderAvdelning', 'AllmanText','SNI2002UnderAvdelning',1

exec sp_Insert_SniKod_Dot  'TA_SNI2002HuvudGrupp', 'AllmanText','SNI2002HuvudGrupp',1
exec sp_Insert_SniKod_Dot  'TA_SNI2002Grupp', 'AllmanText','SNI2002Grupp',1
exec sp_Insert_SniKod_Dot  'TA_SNI2002DetaljGrupp', 'AllmanText','SNI2002DetaljGrupp',1

exec sp_Insert_SniKod_Dot  'TA_SNI2002Avdelning', 'AllmanText','SNI2002Avdelning',1

--Uppdatera T-tabellerna med 2 nycklar
exec sp_Insert_SniKod_Dot_Keys_2  'T_SNI2007Uppslag', 'UppslagText','SNI2007DetaljGrupp','OrdNr',2
exec sp_Insert_SniKod_Dot_Keys_2  'T_SNI2002Uppslag', 'UppslagText','SNI2002DetaljGrupp','OrdNr',2


--Uppdatera T-tabellerna med 3 nycklar

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2007UnderGrupp', 'DelText','SNI2007UnderGrupp','OmfTyp','OrdNr',2
exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2007HuvudGrupp', 'DelText','SNI2007HuvudGrupp','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2007Grupp', 'DelText','SNI2007Grupp','OmfTyp','OrdNr',2
exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2007DetaljGrupp', 'DelText','SNI2007DetaljGrupp','OmfTyp','OrdNr',2 

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2007Avdelning', 'DelText','SNI2007Avdelning','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002UnderGrupp', 'DelText','SNI2002UnderGrupp','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002UnderAvdelning', 'DelText','SNI2002UnderAvdelning','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002HuvudGrupp', 'DelText','SNI2002HuvudGrupp','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002Grupp', 'DelText','SNI2002Grupp','OmfTyp','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002DetaljGrupp', 'DelText','SNI2002DetaljGrupp','OmfTyp','OrdNr',2 

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002Avdelning', 'DelText','SNI2002Avdelning','OmfTyp','OrdNr',2   --funkar inte

exec sp_Insert_SniKod_Dot_Keys_3  'T_SNI2002DetaljGrupp', 'DelText','SNI2002DetaljGrupp','OmfTyp','OrdNr',2 


--Uppdatera H_T-tabellerna med 5 nycklar

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002Avdelning', 'DelText','SNI2002Avdelning','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002DetaljGrupp', 'DelText','SNI2002DetaljGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002Grupp', 'DelText','SNI2002Grupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002HuvudGrupp', 'DelText','SNI2002HuvudGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002UnderAvdelning', 'DelText','SNI2002UnderAvdelning','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2002UnderGrupp', 'DelText','SNI2002UnderGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007Avdelning', 'DelText','SNI2007Avdelning','OmfTyp','StartDat','SlutDat','OrdNr',2


exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007DetaljGrupp', 'DelText','SNI2007DetaljGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007Grupp', 'DelText','SNI2007Grupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007HuvudGrupp', 'DelText','SNI2007HuvudGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007UnderGrupp', 'DelText','SNI2007UnderGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2

exec sp_Insert_SniKod_Dot_Keys_5  'H_T_SNI2007UnderGrupp', 'DelText','SNI2007UnderGrupp','OmfTyp','StartDat','SlutDat','OrdNr',2