if (typeof bobj == 'undefined') {
    bobj = {};
};

bobj.Colors = {
    BLACK :'#000000',
    GRAY :'#a5a5a5'
};
