﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SNIAdminServer.Model;
namespace SNIAdmin.Models
{
    public class NivaAndAktivitetsArt
    {
        public List<Aktivitetsart> AktivitetsArtikelList { get; set; }
        public List<Niva> NivaList { get; set; }
        public List<NivaSNIkod> NivaSNIkodList { get; set; }
        public List<T_SNI2007Uppslag> SNI2007UppslagList { get; set; }
        public List<Rubriker> SNI2007RubrikList { get; set; }
        public List<Omfattar> SNI2007OmfattarList { get; set; }
        public List<Omfattar> SNI2007InteSpecialList { get; set; }
        public List<Allman> SNI2007AllmanText { get; set; }
        public List<RuleValidationNiva> ValidateErrorNiva { get; set; }
        
        public bool ErrorNiva = false;
        public bool UppslagAliasExists = false;

        
      
    }

    

}