﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SNIAdminServer.Model;

namespace SNIAdmin.Models
{
    public class UppslagsMissAndAliasSokOrd
    {
        public List<UppslagsMiss> UppslagsMiss { get; set; }
        public List<AliasSokOrd> AliasSokOrd { get; set; }
        public List<T_SNI2007Uppslag> SniUppslag { get; set; }
        public List<RuleValidation> ValidateError { get; set; }


        public string RefreshViewAliasSokOrd { get; set; }
       
    }
}