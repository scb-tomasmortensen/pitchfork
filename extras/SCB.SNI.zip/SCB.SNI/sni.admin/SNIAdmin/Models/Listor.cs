﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SNIAdminServer.Model;
namespace SNIAdmin.Models
{
    public class Listor
    {
                
        public string ReportPath { get; set; }
        public List<Aktivitetsart> AktivitetsArtikelList { get; set; }

        //listval
        public string ReportName { get; set; }
        public string RapportRubrik { get; set; }

        public string AktBranch { get; set; }
        public bool AktArtUt { get; set; }

        public bool VisaAvd { get; set; }
        public bool VisaAvdAllm { get; set; }
        public bool VisaAvdOmf { get; set; }       

        public bool VisaHGrp { get; set; }
        public bool VisaHGrpAllm { get; set; }
        public bool VisaHGrpOmf { get; set; }

        public bool VisaGrp { get; set; }
        public bool VisaGrpAllm { get; set; }
        public bool VisaGrpOmf { get; set; }

        public bool VisaUGrp { get; set; }
        public bool VisaUGrpAllm { get; set; }
        public bool VisaUGrpOmf { get; set; }

        public bool VisaDGrp { get; set; }
        public bool VisaDGrpAllm { get; set; }
        public bool VisaDGrpOmf { get; set; }
        public bool VisaDGrpUppsl { get; set; }

        public bool VisaSniKod { get; set; }
        public List<string> Snikoder { get; set; }
    }
}