﻿using SNIAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SNIAdminServer.Model;
using SNIAdminServer.Presentation;
using System.Data.Entity.Infrastructure;

namespace SNIAdmin.Controllers
{
    /// <summary>
    /// Controller som hanterar snikoder, AF01
    /// </summary>
    
    public class HemController : Controller
    {

        public ActionResult Index(string nivan, string snikod)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                model.NivaList = server.GetAllaNiva();

                //räkna antal tecken i snikod, därefter kolla vilken nivå sökningen ska ske på...
                //ta hand om sökningen på klienten så att rätt kod är aktiv? hur? MAx 5 siffror(förutom första siffran) måste hanteras, detta också på klienten?
                if (!String.IsNullOrEmpty(snikod))
                {
                    var antal = snikod.Count();
                
                    if (antal == 1)
                    {
                        nivan = "A";
                        model.AktivitetsArtikelList = server.GetAktivitetsArtByNiva(nivan);
                    }
                    else
                    {
                        nivan = Convert.ToString(antal);
                        model.AktivitetsArtikelList = server.GetAktivitetsArtByNiva(nivan);
                    }
                 
                }

                else
                {
                    if (String.IsNullOrEmpty(nivan))
                    {
                        model.AktivitetsArtikelList = server.GetAktivitetsArtByNiva("5");
                    }
                    else
                    {
                        model.AktivitetsArtikelList = server.GetAktivitetsArtByNiva(nivan);
                    }
                }
          
                return View(model);
            }
            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        public ActionResult _NavTabsIndex(string SNIKod)
        {
            try
            {
                return PartialView();
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        public ActionResult _Uppslag(string SNIKod)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();               

                //Lägger över snikod i en egen lista
                //Uppslag endast på 5-siffernivå! Om snikod är null eller ej fem siffror lämnas listan null, kontroll i viewn på listan.
                model.NivaSNIkodList = UppslagNivaSNI(SNIKod);

                model.SNI2007UppslagList = server.GetUppslagsText(SNIKod);

            return PartialView("_Uppslag", model);

            }
            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }

        }

        public List<NivaSNIkod> UppslagNivaSNI(string SNIKod)
        {
            //Uppslag endast på 5-siffernivå! Om snikod är null eller ej fem siffror lämnas listan null, kontroll viewn på listan.
            var model = new Models.NivaAndAktivitetsArt();

            if (!String.IsNullOrEmpty(SNIKod))
            {
                var antal = SNIKod.Count();

                if (antal == 5)
                {
                    List<NivaSNIkod> lista = new List<NivaSNIkod>
                    {
                        new NivaSNIkod { 
                            Kod = SNIKod,
                            Niva = "5"
                        }
                    };
                    
                    return lista;                   
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }

        public ActionResult _ValideraUppslag(int UppdateTyp, short OrdNr, string SNIKod, string NySNIKod, string SNIKod2002, string Text)
        {
            try
            {
                //Uppdateringstyper: Text = 1, 2007kod = 2, 2002kod = 3, nyrad = 4
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                switch (UppdateTyp)
                {
                    case 1://UppslagsText
                        model.ValidateErrorNiva = server.ValideraUppslagsText(Text);

                        //Finns fel kontrollera om det är ett "aliasfel" (ligger i ErrorMessage). Meddela användaren ifall man ska spara ändå (sker på klienten).
                        if (model.ValidateErrorNiva != null && model.ValidateErrorNiva.Count != 0)
                        {
                            model.ErrorNiva = true;//Fel finns
                            model.UppslagAliasExists = model.ValidateErrorNiva[0].ErrorMessage == "alias" ? true : false; //"Aliasfel" eller inte.
                        }

                    break;
                    case 2:// SNIKod
                         model.ValidateErrorNiva = server.ValideraUppslagKod(NySNIKod);

                        //Finns fel meddela användaren.
                        if (model.ValidateErrorNiva != null && model.ValidateErrorNiva.Count != 0)
                        {
                            model.ErrorNiva = true;//Fel finns                       
                        }


                    break;
                    case 3://SNI2002Kod
                        model.ValidateErrorNiva = server.ValideraUppslag2002Kod(SNIKod2002);

                        //Finns fel meddela användaren.
                        if (model.ValidateErrorNiva != null && model.ValidateErrorNiva.Count != 0)
                        {
                            model.ErrorNiva = true;//Fel finns                       
                        }
                    break;
                    case 4://Ny rad. Kontrollerar alla inputfält utom Kod (Kod läggs upp automatisk på klienten och behöver då inte kontrolleras)
                        //Kontroll SNI2002
                        model.ValidateErrorNiva = server.ValideraUppslag2002Kod(SNIKod2002);

                        if (model.ValidateErrorNiva == null || model.ValidateErrorNiva.Count == 0)
                        {
                            //Kontroll Uppslagstext
                            model.ValidateErrorNiva = server.ValideraUppslagsText(Text);                        
                        }
                    
                        //Finns fel kontrollera om det är ett "aliasfel" (ligger i ErrorMessage). Meddela användaren ifall man ska spara ändå (sker på klienten).
                        if (model.ValidateErrorNiva != null && model.ValidateErrorNiva.Count != 0)
                        {
                            model.ErrorNiva = true;//Fel finns
                            model.UppslagAliasExists = model.ValidateErrorNiva[0].ErrorMessage == "alias" ? true : false; //"Aliasfel" eller inte.
                        }
                    break;
                    default:
                        break;
                }

                //Lägger över snikod i en egen lista
                //Uppslag endast på 5-siffernivå! Om snikod är null eller ej fem siffror lämnas listan null, kontroll i viewn på listan.
                model.NivaSNIkodList = UppslagNivaSNI(SNIKod);

                model.SNI2007UppslagList = server.GetUppslagsText(SNIKod);

                return PartialView("_Uppslag",model);
                }
            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }

        }

        [HttpPost]
        public ActionResult _UppdateraUppslag(int UppdateTyp, short OrdNr, string SNIKod, string NySNIKod, string SNIKod2002, string Text, byte RedKod, string user)
        { 
            try
            {
                //Kontrollen gjord innan, endast uppdatering sker här!
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                string anvandare = user.Replace("SCB\\", "");
           

                switch (UppdateTyp)
                {
                    case 1://UppslagsText
                        server.UppdateraUppslagsText(OrdNr, SNIKod, Text, RedKod, anvandare);
                        break;
                    case 2:// SNIKod
                        server.UppdateraUppslagKod(OrdNr, SNIKod, NySNIKod, anvandare);
                        break;
                    case 3://SNI2002Kod
                        server.UppdateraUppslagSNI2002Kod(OrdNr, SNIKod, SNIKod2002, anvandare);
                        break;
                    case 4://Ny rad
                        server.NyttUppslag(SNIKod, SNIKod2002, Text, anvandare);
                        break;
                    default:
                        break;
                }

                //Lägger över snikod i en egen lista
                //Uppslag endast på 5-siffernivå! Om snikod är null eller ej fem siffror lämnas listan null, kontroll i viewn på listan.
                model.NivaSNIkodList = UppslagNivaSNI(SNIKod);

                model.SNI2007UppslagList = server.GetUppslagsText(NySNIKod);

                return PartialView("_Uppslag", model);

            }
            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }

        
        public ActionResult _NyRadUppslag(int OrdNr, string SNIKod, string Text, string SNI2002Kod, byte RedKod)
        {

            return PartialView("_Uppslag");
        }

        public ActionResult _DeleteUppslag(int OrdNr, string SNIKod, string user)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                string anvandare = user.Replace("SCB\\", "");

                server.DeleteUppslagsText(OrdNr,SNIKod, anvandare);
                ModelState.Clear(); //important to see changes in UI

                //Lägger över snikod i en egen lista
                //Uppslag endast på 5-siffernivå! Om snikod är null eller ej fem siffror lämnas listan null, kontroll i viewn på listan.
                model.NivaSNIkodList = UppslagNivaSNI(SNIKod);
                
                model.SNI2007UppslagList = server.GetUppslagsText(SNIKod);

                return PartialView("_Uppslag", model);
            }


            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }


        public ActionResult _Rubrik(string SNIKod, string niva)
        {
            try 
            { 
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                //if (!String.IsNullOrEmpty(niva) && !String.IsNullOrEmpty(SNIKod))
                if (!String.IsNullOrEmpty(SNIKod))
                {
                    var antal = SNIKod.Count();

                    if (antal == 1)
                    {
                        niva = "A";
                    }
                    else
                    {
                        niva = Convert.ToString(antal);
                    }
                }

                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };

                model.NivaSNIkodList = nivasni;
                model.SNI2007RubrikList = server.GetRubrikByNivaAndSNIkod(SNIKod, niva);
                       
                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }

        }

        public ActionResult _UppdateraRubrik(string SNIKod, string niva, string Aktivitetsart, string Bransch, string AktArtUtokad, string RedKod, string  user)
        {
            try
            {

                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                string anvandare = user.Replace("SCB\\", "");

                server.UpdateRubrikByNivaAndSNIkod(SNIKod, niva, Aktivitetsart, Bransch, AktArtUtokad, RedKod, anvandare);

                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                model.SNI2007RubrikList = server.GetRubrikByNivaAndSNIkod(SNIKod, niva);

                return PartialView(model); 
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }



        public ActionResult _Omfattar(string SNIKod, string niva)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                if (String.IsNullOrEmpty(niva) && !String.IsNullOrEmpty(SNIKod))
                {
                    var antal = SNIKod.Count();

                    if (antal == 1)
                    {
                        niva = "A";
                    }
                    else
                    {
                        niva = Convert.ToString(antal);
                    }
                }

                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                //omfattartyp 1 och 2 
                model.SNI2007OmfattarList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIKod, niva, 1, 2);

                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }

        }

        public ActionResult _InteSpecial(string SNIKod, string niva)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                if (String.IsNullOrEmpty(niva) && !String.IsNullOrEmpty(SNIKod))
                {
                    var antal = SNIKod.Count();

                    if (antal == 1)
                    {
                        niva = "A";
                    }
                    else
                    {
                        niva = Convert.ToString(antal);
                    }
                }

                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                //omfattartyp 3 och 4 
                model.SNI2007InteSpecialList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIKod, niva, 3, 4);

                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }

        }
        public ActionResult _ValideraOmfattarInteSpecial(List<OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp)
        {
            try
            {
                //Används förnärvarande inte!!! Läggs in i listan över saker att att göra...
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                model.ValidateErrorNiva = server.ValideraOmfattarInteSpecial(omfattarlist);

                if (model.ValidateErrorNiva != null && model.ValidateErrorNiva.Count != 0)
                {
                    model.ErrorNiva = true;//Fel finns
                }

                //Hämtar de sparade värdena
                if (OmfTyp == 1 || OmfTyp == 2)//omfattartyp 1 och 2 
                {
                    model.SNI2007OmfattarList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIkod, niva, 1, 2);
                }
                else //omfattartyp 3 och 4 
                {
                    model.SNI2007InteSpecialList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIkod, niva, 3, 4);
                }


                return PartialView("_Omfattar", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }

        }

        public ActionResult _UppdateraOmfattarInteSpecial(List<OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string user)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                string anvandare = user.Replace("SCB\\", "");

                server._UpdateOmfattarInteSpecial(omfattarlist, niva, SNIkod, OmfTyp, RedKod, anvandare);


                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIkod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                //Hämtar de sparade värdena
                if (OmfTyp == 1 || OmfTyp == 2)
                {
                    //omfattartyp 1 och 2 
                    model.SNI2007OmfattarList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIkod, niva, 1, 2);
                    return PartialView("_Omfattar", model);
                }
                else
                {
                    //omfattartyp 3 och 4 
                    model.SNI2007InteSpecialList = server.GetOmfattarByNivaSNIkodAndOmfTyp(SNIkod, niva, 3, 4);
                    return PartialView("_InteSpecial", model);
                }
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        
        }
        
        public ActionResult _AllmanText(string SNIKod, string niva)
        {
            try
            {
                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                if (String.IsNullOrEmpty(niva) && !String.IsNullOrEmpty(SNIKod))
                {
                    var antal = SNIKod.Count();

                    if (antal == 1)
                    {
                        niva = "A";
                    }
                    else
                    {
                        niva = Convert.ToString(antal);
                    }
                }
                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                model.SNI2007AllmanText = server.GetAllmanTextByNivaAndSNIkod(SNIKod, niva);

                return PartialView(model);

            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }

        }

        [HttpPost]
        public ActionResult _UppdateraAllmanText(string SNIKod, string niva, string allmanText, string user)
        {
            try 
            { 

                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();
                string anvandare = user.Replace("SCB\\", "");

                //Lägger över niva och snikod i en egen lista.
                List<NivaSNIkod> nivasni = new List<NivaSNIkod>
                {
                    new NivaSNIkod { 
                        Kod = SNIKod,
                        Niva = niva
                    }
               
                };
                model.NivaSNIkodList = nivasni;

                server.UpdateAllmanTextByNivaAndSNIkod(SNIKod, niva, allmanText, anvandare);

                model.SNI2007AllmanText = server.GetAllmanTextByNivaAndSNIkod(SNIKod, niva);

                return PartialView("_AllmanText", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        public ActionResult _DeleteAllmanText(string SNIKod, string niva)
        {
            try 
            { 

                var server = new SelectNivaAndUpdatePresentation();
                var model = new Models.NivaAndAktivitetsArt();

                server.DeleteAllmanTextByNivaAndSNIkod(SNIKod, niva);

                model.SNI2007AllmanText = server.GetAllmanTextByNivaAndSNIkod(SNIKod, niva);

                return PartialView("_AllmanText", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        public ActionResult Listor()          
        { 
            try
            {
                return View();
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }

        }

    }
}
