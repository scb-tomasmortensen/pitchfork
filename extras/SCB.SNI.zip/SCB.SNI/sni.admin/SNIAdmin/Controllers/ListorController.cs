﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SNIAdminServer.Model;
using SNIAdminServer.Presentation;
using CrystalDecisions.CrystalReports.Engine;
using System.IO;
using SNIAdmin.Models;

namespace SNIAdmin.Controllers
{
    public class ListorController : Controller
    {
        /// <summary>
        /// Controller som hanterar Listor, AF02
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            try
            {
                return RedirectToAction("Index", "Hem"); 
            }

            catch (Exception ex)
            {
            return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }


        public ActionResult ValAvListor()
        {
            try 
            {          
                var model = new Models.Listor();          
                return View(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        public ActionResult _SniSortList()
        {
            try
            {
                var server = new ListorPresentation();         
                var model = new Models.Listor();
                model.AktivitetsArtikelList = server.GetAktivitetsArtByNiva("5");

                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }


        public ActionResult _SniSortEngList()
        {
            try
            {
                var model = new Models.Listor();
                return PartialView("_SniSortEngList",model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }

        public ActionResult _AlfabetiskList()
        {
            try
            {

                var model = new Models.Listor();
                return PartialView("_AlfabetiskList",model);

            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }


        [HttpPost]
        public  ActionResult ShowGenericRptInNewWin(string reportName)
        {
            try             
            { 
                System.Web.HttpContext.Current.Session["ReportName"] = reportName;
                var model = new Models.Listor();
                return PartialView("_AlfabetiskList", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult ShowSniSortEng(Listor m)
        {
            try 
            { 
                System.Web.HttpContext.Current.Session["ReportName"] = m.ReportName;
                System.Web.HttpContext.Current.Session["AktBranch"] = m.AktBranch;

                System.Web.HttpContext.Current.Session["VisaAvd"] = m.VisaAvd;
                System.Web.HttpContext.Current.Session["VisaHGrp"] = m.VisaHGrp;
                System.Web.HttpContext.Current.Session["VisaGrp"] = m.VisaGrp;
                System.Web.HttpContext.Current.Session["VisaUGrp"] = m.VisaUGrp;
                System.Web.HttpContext.Current.Session["VisaDGrp"] = m.VisaDGrp;

                var model = new Models.Listor();
                return PartialView("_SniSortEngList", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        
        [HttpPost]
        public ActionResult ShowSniSort(Listor m)
        {
            try 
            { 
                System.Web.HttpContext.Current.Session["ReportName"] = m.ReportName;
                System.Web.HttpContext.Current.Session["RapportRubrik"] = m.RapportRubrik;

                System.Web.HttpContext.Current.Session["AktBranch"] = m.AktBranch;
                System.Web.HttpContext.Current.Session["AktArtUt"] = m.AktArtUt;

                System.Web.HttpContext.Current.Session["VisaAvd"] = m.VisaAvd;
                System.Web.HttpContext.Current.Session["VisaAvdAllm"] = m.VisaAvdAllm;
                System.Web.HttpContext.Current.Session["VisaAvdOmf"] = m.VisaAvdOmf;

                System.Web.HttpContext.Current.Session["VisaHGrp"] = m.VisaHGrp;
                System.Web.HttpContext.Current.Session["VisaHGrpAllm"] = m.VisaHGrpAllm;
                System.Web.HttpContext.Current.Session["VisaHGrpOmf"] = m.VisaHGrpOmf;


                System.Web.HttpContext.Current.Session["VisaGrp"] = m.VisaGrp;
                System.Web.HttpContext.Current.Session["VisaGrpAllm"] = m.VisaGrpAllm;
                System.Web.HttpContext.Current.Session["VisaGrpOmf"] = m.VisaGrpOmf;

                System.Web.HttpContext.Current.Session["VisaUGrp"] = m.VisaUGrp;
                System.Web.HttpContext.Current.Session["VisaUGrpAllm"] = m.VisaUGrpAllm;
                System.Web.HttpContext.Current.Session["VisaUGrpOmf"] = m.VisaUGrpOmf;

                System.Web.HttpContext.Current.Session["VisaDGrp"] = m.VisaDGrp;
                System.Web.HttpContext.Current.Session["VisaDGrpAllm"] = m.VisaDGrpAllm;
                System.Web.HttpContext.Current.Session["VisaDGrpOmf"] = m.VisaDGrpOmf;
                System.Web.HttpContext.Current.Session["VisaDGrpUppsl"] = m.VisaDGrpUppsl;


                string sniKoder = "";

                if (m.Snikoder != null)
                { 
                    foreach (var item in m.Snikoder)
                    {
                        sniKoder = sniKoder + "'" + item.ToString() + "',";
                    }
                    sniKoder= sniKoder.Substring(0, sniKoder.Length - 1);//ta bort sista kommatecknet
                }

                System.Web.HttpContext.Current.Session["SNIKOD"] = sniKoder;  //lista med snikoder 
                //System.Web.HttpContext.Current.Session["VisaSniKod"] = m.VisaSniKod;
           

                var model = new Models.Listor();
                return PartialView("_SniSortList", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        } 
        

    }
}
