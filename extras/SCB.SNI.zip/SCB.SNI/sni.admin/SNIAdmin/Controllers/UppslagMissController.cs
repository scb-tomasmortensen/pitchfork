﻿using SNIAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SNIAdminServer.Model;
using SNIAdminServer.Presentation;


namespace SNIAdmin.Controllers
{
    /// <summary>
    /// Controller som hanterar uppslagsmissar, AF03
    /// </summary>
    public class UppslagMissController : Controller
    {
        //
        // GET: /UppslagMiss/

        public ActionResult Index()
        {
            try 
            { 
                return RedirectToAction("Index", "Hem");
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }
        
       
        public ActionResult Uppslagsmiss()       
        {
            try 
            { 
                var model = new Models.UppslagsMissAndAliasSokOrd();          
                return View(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpGet]
        public ActionResult _Uppslagsmiss()
        {
            try 
            { 
                var server = new HanteraSokOrdPresentation();
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.UppslagsMiss = server.GetAllaUppslagsMiss();
                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult DeleteUppslagsMiss(string[] UppslagMissId)
        {
            try 
            { 
                var server = new HanteraSokOrdPresentation();
                server.DeleteUppslagsMiss(UppslagMissId);
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.UppslagsMiss = server.GetAllaUppslagsMiss();

                return View(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult DeleteUppslagsMissAlla(string[] keepUppslagMissId)
        {
             try
             {
                var server = new HanteraSokOrdPresentation();
                server.DeleteUppslagsMissAlla(keepUppslagMissId);

                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.UppslagsMiss = server.GetAllaUppslagsMiss();
          
                return PartialView("_Uppslagsmiss", model);
            }

            catch (Exception ex)
            {
            return View("Error", new HandleErrorInfo(ex,"Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult DeleteAliasSokOrd(string[] aliasSokOrd)
        {
            try 
            { 
                var server = new HanteraSokOrdPresentation();
                server.DeleteAliasSokOrd(aliasSokOrd);
            
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.AliasSokOrd = server.GetAllaAliasSokOrd("");

                return View(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        [HttpPost]        
        public ActionResult AddAliasSokOrd(string aliasSokOrd, string sokOrd)
        {
            try 
            { 
                ModelState.Clear(); 
                var server = new HanteraSokOrdPresentation();
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.ValidateError = server.AddAliasSokOrd(aliasSokOrd.TrimStart().TrimEnd(), sokOrd.TrimStart().TrimEnd());
                model.AliasSokOrd = server.GetAllaAliasSokOrd("");

                if (model.ValidateError.Count() != 0)
                {
                    model.RefreshViewAliasSokOrd = "false";
                    return PartialView("_AliasSokOrd", model);
                }
                else
                {              
                    model.RefreshViewAliasSokOrd = "true";
                    return PartialView("_AliasSokOrd", model);               
                }
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult UndoAddAliasSokOrd()
        {
            try
            {
                ModelState.Clear(); 
                var server = new HanteraSokOrdPresentation();
           
                var model = new Models.UppslagsMissAndAliasSokOrd();          
                model.AliasSokOrd = server.GetAllaAliasSokOrd("");

                return PartialView("_AliasSokOrd",model);  
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }

        }

        public ActionResult _AliasSokOrd()
        {
            try 
            { 
                var server = new HanteraSokOrdPresentation();
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.AliasSokOrd = server.GetAllaAliasSokOrd("");

                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }

        
        public ActionResult _SNI2007Uppslag()
        {
            try 
            { 
                var model = new Models.UppslagsMissAndAliasSokOrd();           
                return PartialView(model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }


        [HttpPost]
        public ActionResult GetSNI2007Uppslag(string uppslag)
        {
            try 
            { 
                var server = new HanteraSokOrdPresentation();
                var model = new Models.UppslagsMissAndAliasSokOrd();
                model.SniUppslag = server.GetAllaSniUppslag(uppslag);
                return PartialView("_SNI2007Uppslag", model);
            }

            catch (Exception ex)
            {
                return View("Error", new HandleErrorInfo(ex, "Hem", "Index"));
            }
        }
                    
    }
}
