﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared; 

namespace SNIAdmin.Reports.CrystalViewer
{
    public partial class MyCrystalViewer : System.Web.UI.Page
    {
        public string thisConnectionString = ConfigurationManager.ConnectionStrings["FDBIntSniContext"].ConnectionString;
        CrystalDecisions.CrystalReports.Engine.ReportDocument reportDocument = null;

        public string reportName;

        protected void Page_Load(object sender, EventArgs e)
        {  
             //  ReportName 
            reportName = System.Web.HttpContext.Current.Session["ReportName"].ToString();
            LoadReport();
          
        }


        private void LoadReport()
        {
            if (this.reportDocument != null)
            {
                this.reportDocument.Close();
                this.reportDocument.Dispose();
            }
            SqlConnectionStringBuilder SConn = new SqlConnectionStringBuilder(ConfigurationManager.ConnectionStrings["FDBIntSniContext"].ConnectionString);
            SqlConnection thisConnection = new SqlConnection(thisConnectionString);
           
            reportDocument = new ReportDocument();
            //Report path            
            string reportPath = Server.MapPath("~/Reports/Crystal/" + reportName);

            reportDocument.Load(reportPath);
            // Report connection 
            ConnectionInfo connInfo = new ConnectionInfo();
            connInfo.ServerName = SConn.DataSource;
            connInfo.DatabaseName = SConn.InitialCatalog;
            connInfo.IntegratedSecurity = true;          
            TableLogOnInfo tableLogOnInfo = new TableLogOnInfo();
            tableLogOnInfo.ConnectionInfo = connInfo;
            foreach (CrystalDecisions.CrystalReports.Engine.Table table in reportDocument.Database.Tables)
            {
                table.ApplyLogOnInfo(tableLogOnInfo);
                table.LogOnInfo.ConnectionInfo = connInfo;                                             
            }
             
                  
            FormulaFieldDefinitions crFormFields;

            switch (reportName)
            {
                case "SnisorteradSub_1.rpt":
                   crFormFields = reportDocument.DataDefinition.FormulaFields;
                  
                    foreach (FormulaFieldDefinition crFormField in crFormFields)
                    {
                        switch (crFormField.Name )
                        {
                            //Aktivitetsart eller Branch
                            case "optA_Aktivitet_Bransch":                         
                            case "optHG_Aktivitet_Bransch":
                            case "optG_Aktivitet_Bransch":
                            case "optUG_Aktivitet_Bransch":
                            case "optDG_Aktivitet_Bransch":
                          
                                var aktBranch =  System.Web.HttpContext.Current.Session["AktBranch"].ToString();                       
                                crFormField.Text = (aktBranch == "aktivitet") ? "'A'" : "'B'";   
                                break;                          
                            
                                //Nivå
                            case "chkA":
                                bool avd = (bool)System.Web.HttpContext.Current.Session["VisaAvd"];
                                crFormField.Text = (avd==true ) ? "'J'" : "'N'";                                       
                                break;                           
                            case "chkHG":
                                bool hGrupp = (bool)System.Web.HttpContext.Current.Session["VisaHGrp"];
                                crFormField.Text = (hGrupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkG":
                                bool grupp = (bool)System.Web.HttpContext.Current.Session["VisaGrp"];
                                crFormField.Text = (grupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkUG":
                                bool uGrupp = (bool)System.Web.HttpContext.Current.Session["VisaUGrp"];
                                crFormField.Text = (uGrupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkDG":
                                bool dGrupp = (bool)System.Web.HttpContext.Current.Session["VisaDGrp"];
                                crFormField.Text = (dGrupp == true) ? "'J'" : "'N'";                                       
                                break;

                             //omfattartext
                            case "optA_Omf":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaAvd"])
                                { 
                                     bool avdOmf = (bool)System.Web.HttpContext.Current.Session["VisaAvdOmf"];
                                     crFormField.Text = (avdOmf == true) ? "'J'" : "'N'";    
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }                                                               
                                break;                           

                            case "optHG_Omf":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaHGrp"])
                                {
                                    bool hgOmf = (bool)System.Web.HttpContext.Current.Session["VisaHGrpOmf"];
                                     crFormField.Text = (hgOmf == true) ? "'J'" : "'N'";    
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }                                                               
                                break;         

                            case "optG_Omf":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaGrp"])
                                {
                                    bool gOmf = (bool)System.Web.HttpContext.Current.Session["VisaGrpOmf"];
                                    crFormField.Text = (gOmf == true) ? "'J'" : "'N'";    
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }                                                               
                                break;       

                            case "optUG_Omf":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaUGrp"])
                                {
                                    bool ugOmf = (bool)System.Web.HttpContext.Current.Session["VisaUGrpOmf"];
                                    crFormField.Text = (ugOmf == true) ? "'J'" : "'N'";    
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }                                                               
                                break;      

                            case "optDG_Omf":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaDGrp"])
                                {
                                    bool dgOmf = (bool)System.Web.HttpContext.Current.Session["VisaDGrpOmf"];
                                    crFormField.Text = (dgOmf == true) ? "'J'" : "'N'";    
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }                                                               
                                break;

                            //allmäntext
                            case "optA_Allm":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaAvd"])
                                {
                                    bool avdAllm = (bool)System.Web.HttpContext.Current.Session["VisaAvdAllm"];
                                    crFormField.Text = (avdAllm == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break;

                            case "optHG_Allm":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaHGrp"])
                                {
                                    bool hgAllm = (bool)System.Web.HttpContext.Current.Session["VisaHGrpAllm"];
                                    crFormField.Text = (hgAllm == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break;

                            case "optG_Allm":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaGrp"])
                                {
                                    bool gAllm = (bool)System.Web.HttpContext.Current.Session["VisaGrpAllm"];
                                    crFormField.Text = (gAllm == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break;

                            case "optUG_Allm":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaUGrp"])
                                {
                                    bool ugAllm = (bool)System.Web.HttpContext.Current.Session["VisaUGrpAllm"];
                                    crFormField.Text = (ugAllm == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break;

                            case "optDG_Allm":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaDGrp"])
                                {
                                    bool dgAllm = (bool)System.Web.HttpContext.Current.Session["VisaDGrpAllm"];
                                    crFormField.Text = (dgAllm == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break;

                            //Uppslagstext
                            case "optUppslag":
                                if ((bool)System.Web.HttpContext.Current.Session["VisaDGrp"])
                                {
                                    bool dgUppsl = (bool)System.Web.HttpContext.Current.Session["VisaDGrpUppsl"];
                                    crFormField.Text = (dgUppsl == true) ? "'J'" : "'N'";
                                }
                                else
                                {
                                    crFormField.Text = "'N'";
                                }
                                break; 

                            //rubrik
                            case "L1Rubrik":

                                crFormField.Text = "'"  + System.Web.HttpContext.Current.Session["RapportRubrik"].ToString() + "'";// System.Web.HttpContext.Current.Session["RapportRubrik"].ToString() ;
                                break;


                        }

                    }

                    //Selection på snikoder
                    if (System.Web.HttpContext.Current.Session["SNIKOD"].ToString() == "")
                    {
                        reportDocument.RecordSelectionFormula = "";
                    }
                    else
                    {
                        string sniKod = "{K_SNI2002DetaljGrupp.SNI2007DetaljGrupp} in [" + System.Web.HttpContext.Current.Session["SNIKOD"].ToString() + "]";
                        reportDocument.RecordSelectionFormula = sniKod;
                    }
                    break;

                case "SnisorteradEng.rpt":
                    crFormFields = reportDocument.DataDefinition.FormulaFields;                

                    foreach (FormulaFieldDefinition crFormField in crFormFields)
                    {
                        switch (crFormField.Name )
                        {
                            //aktivetesart/branch
                            case "optA_Aktivitet_Bransch":                         
                            case "optHG_Aktivitet_Bransch":
                            case "optG_Aktivitet_Bransch":
                            case "optUG_Aktivitet_Bransch":
                            case "optDG_Aktivitet_Bransch":
                          
                                var aktBranch =  System.Web.HttpContext.Current.Session["AktBranch"].ToString();                       
                                crFormField.Text = (aktBranch == "aktivitet") ? "'A'" : "'B'";   
                                break;                          
                                
                            //nivå
                            case "chkA":
                                bool avd = (bool)System.Web.HttpContext.Current.Session["VisaAvd"];
                                crFormField.Text = (avd==true ) ? "'J'" : "'N'";                                       
                                break;                           
                            case "chkHG":
                                bool hGrupp = (bool)System.Web.HttpContext.Current.Session["VisaHGrp"];
                                crFormField.Text = (hGrupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkG":
                                bool grupp = (bool)System.Web.HttpContext.Current.Session["VisaGrp"];
                                crFormField.Text = (grupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkUG":
                                bool uGrupp = (bool)System.Web.HttpContext.Current.Session["VisaUGrp"];
                                crFormField.Text = (uGrupp == true) ? "'J'" : "'N'";                                       
                                break;
                            case "chkDG":
                                bool dGrupp = (bool)System.Web.HttpContext.Current.Session["VisaDGrp"];
                                crFormField.Text = (dGrupp == true) ? "'J'" : "'N'";                                       
                                break;
                                // Todo Sätts aldrig, ta bort?
                            case "L2Rubrik":
                                crFormField.Text = "'TEST'";
                                break;
                        }

                    }

                
                    break;

                case "L3Alfabetis.rpt":
                    //inga parametrar
                    break;

            }

            GenericReport.ReportSource = reportDocument;       
                        
           
        } 



    }
}