using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class TA_SNI2007HuvudGruppMap : EntityTypeConfiguration<TA_SNI2007HuvudGrupp>
    {
        public TA_SNI2007HuvudGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007HuvudGrupp);

            // Properties
            this.Property(t => t.SNI2007HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2007HuvudGrupp");
            this.Property(t => t.SNI2007HuvudGrupp).HasColumnName("SNI2007HuvudGrupp");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007HuvudGrupp)
                .WithOptional(t => t.TA_SNI2007HuvudGrupp);

        }
    }
}
