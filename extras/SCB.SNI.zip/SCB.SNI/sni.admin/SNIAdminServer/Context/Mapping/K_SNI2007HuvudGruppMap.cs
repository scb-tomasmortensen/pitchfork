using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class K_SNI2007HuvudGruppMap : EntityTypeConfiguration<K_SNI2007HuvudGrupp>
    {
        public K_SNI2007HuvudGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007HuvudGrupp);

            // Properties
            this.Property(t => t.SNI2007HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2007Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("K_SNI2007HuvudGrupp");
            this.Property(t => t.SNI2007HuvudGrupp).HasColumnName("SNI2007HuvudGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2007Avdelning).HasColumnName("SNI2007Avdelning");

            // Relationships
            this.HasRequired(t => t.K_SNI2007Avdelning)
                .WithMany(t => t.K_SNI2007HuvudGrupp)
                .HasForeignKey(d => d.SNI2007Avdelning);

        }
    }
}
