using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class K_SNI2002DetaljGruppMap : EntityTypeConfiguration<K_SNI2002DetaljGrupp>
    {
        public K_SNI2002DetaljGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002DetaljGrupp);

            // Properties
            this.Property(t => t.SNI2002DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.AktivitetsArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("K_SNI2002DetaljGrupp");
            this.Property(t => t.SNI2002DetaljGrupp).HasColumnName("SNI2002DetaljGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.AktivitetsArtUtokad).HasColumnName("AktivitetsArtUtokad");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002UnderGrupp).HasColumnName("SNI2002UnderGrupp");

            // Relationships
            this.HasMany(t => t.K_SNI2007DetaljGrupp)
                .WithMany(t => t.K_SNI2002DetaljGrupp)
                .Map(m =>
                    {
                        m.ToTable("T_SNI2002_2007");
                        m.MapLeftKey("SNI2002DetaljGrupp");
                        m.MapRightKey("SNI2007DetaljGrupp");
                    });


            //this.HasMany(t => t.K_SNI92DetaljGrupp)
            //    .WithMany(t => t.K_SNI2002DetaljGrupp)
            //    .Map(m =>
            //        {
            //            m.ToTable("T_SNI92_2002");
            //            m.MapLeftKey("SNI2002DetaljGrupp");
            //            m.MapRightKey("SNI92DetaljGrupp");
            //        });

            this.HasRequired(t => t.K_SNI2002UnderGrupp)
                .WithMany(t => t.K_SNI2002DetaljGrupp)
                .HasForeignKey(d => d.SNI2002UnderGrupp);

        }
    }
}
