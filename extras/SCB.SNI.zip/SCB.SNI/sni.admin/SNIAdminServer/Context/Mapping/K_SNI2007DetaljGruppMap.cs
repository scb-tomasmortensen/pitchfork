using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class K_SNI2007DetaljGruppMap : EntityTypeConfiguration<K_SNI2007DetaljGrupp>
    {
        public K_SNI2007DetaljGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007DetaljGrupp);

            // Properties
            this.Property(t => t.SNI2007DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.AktivitetsArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2007UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("K_SNI2007DetaljGrupp");
            this.Property(t => t.SNI2007DetaljGrupp).HasColumnName("SNI2007DetaljGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.AktivitetsArtUtokad).HasColumnName("AktivitetsArtUtokad");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2007UnderGrupp).HasColumnName("SNI2007UnderGrupp");

            
            // Relationships
            this.HasRequired(t => t.K_SNI2007UnderGrupp)
                .WithMany(t => t.K_SNI2007DetaljGrupp)
                .HasForeignKey(d => d.SNI2007UnderGrupp);

        }
    }
}
