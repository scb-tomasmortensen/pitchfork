using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class TA_SNI2007AvdelningMap : EntityTypeConfiguration<TA_SNI2007Avdelning>
    {
        public TA_SNI2007AvdelningMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007Avdelning);

            // Properties
            this.Property(t => t.SNI2007Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2007Avdelning");
            this.Property(t => t.SNI2007Avdelning).HasColumnName("SNI2007Avdelning");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007Avdelning)
                .WithOptional(t => t.TA_SNI2007Avdelning);

        }
    }
}
