using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class T_SNI2007HuvudGruppMap : EntityTypeConfiguration<T_SNI2007HuvudGrupp>
    {
        public T_SNI2007HuvudGruppMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007HuvudGrupp, t.OmfTyp, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2007HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("T_SNI2007HuvudGrupp");
            this.Property(t => t.SNI2007HuvudGrupp).HasColumnName("SNI2007HuvudGrupp");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007HuvudGrupp)
                .WithMany(t => t.T_SNI2007HuvudGrupp)
                .HasForeignKey(d => d.SNI2007HuvudGrupp);

        }
    }
}
