using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class H_T_SNI2007UnderGruppMap : EntityTypeConfiguration<H_T_SNI2007UnderGrupp>
    {
        public H_T_SNI2007UnderGruppMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007UnderGrupp, t.OmfTyp, t.StartDat, t.SlutDat, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2007UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("H_T_SNI2007UnderGrupp");
            this.Property(t => t.SNI2007UnderGrupp).HasColumnName("SNI2007UnderGrupp");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.StartDat).HasColumnName("StartDat");
            this.Property(t => t.SlutDat).HasColumnName("SlutDat");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007UnderGrupp)
                .WithMany(t => t.H_T_SNI2007UnderGrupp)
                .HasForeignKey(d => d.SNI2007UnderGrupp);

        }
    }
}
