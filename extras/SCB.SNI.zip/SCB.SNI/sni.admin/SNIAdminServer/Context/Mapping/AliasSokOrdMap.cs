﻿using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class AliasSokOrdMap : EntityTypeConfiguration<AliasSokOrd>
    {
        public AliasSokOrdMap()
        {
            // Primary Key
            this.HasKey(t => t.AliasSokOrd1);

            // Properties
            this.Property(t => t.AliasSokOrd1)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.SokOrd)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("AliasSokOrd");
            this.Property(t => t.AliasSokOrd1).HasColumnName("AliasSokOrd");
            this.Property(t => t.SokOrd).HasColumnName("SokOrd");
        }
    }
}
