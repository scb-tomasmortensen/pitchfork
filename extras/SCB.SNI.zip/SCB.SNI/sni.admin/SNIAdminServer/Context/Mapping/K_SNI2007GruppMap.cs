using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class K_SNI2007GruppMap : EntityTypeConfiguration<K_SNI2007Grupp>
    {
        public K_SNI2007GruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007Grupp);

            // Properties
            this.Property(t => t.SNI2007Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2007HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            // Table & Column Mappings
            this.ToTable("K_SNI2007Grupp");
            this.Property(t => t.SNI2007Grupp).HasColumnName("SNI2007Grupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2007HuvudGrupp).HasColumnName("SNI2007HuvudGrupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2007HuvudGrupp)
                .WithMany(t => t.K_SNI2007Grupp)
                .HasForeignKey(d => d.SNI2007HuvudGrupp);

        }
    }
}
