using SNIAdminServer.Model;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SNIAdminServer.Context.Mapping
{
    public class K_SNI2007UnderGruppMap : EntityTypeConfiguration<K_SNI2007UnderGrupp>
    {
        public K_SNI2007UnderGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007UnderGrupp);

            // Properties
            this.Property(t => t.SNI2007UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2007Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            // Table & Column Mappings
            this.ToTable("K_SNI2007UnderGrupp");
            this.Property(t => t.SNI2007UnderGrupp).HasColumnName("SNI2007UnderGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2007Grupp).HasColumnName("SNI2007Grupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2007Grupp)
                .WithMany(t => t.K_SNI2007UnderGrupp)
                .HasForeignKey(d => d.SNI2007Grupp);

        }
    }
}
