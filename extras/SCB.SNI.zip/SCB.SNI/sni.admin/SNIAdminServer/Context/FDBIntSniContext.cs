using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using SNIAdminServer.Model;
using SNIAdminServer.Context.Mapping;

namespace SNIAdminServer
{
    public partial class FDBIntSniContext : DbContext
    {
        static FDBIntSniContext()
        {
            Database.SetInitializer<FDBIntSniContext>(null);
        }

        public FDBIntSniContext()
            : base("Name=FDBIntSniContext")
        {
        }
        //K_SNI2007Avdelning
        public DbSet<K_SNI2007Avdelning> K_SNI2007Avdelnings { get; set; }
        public DbSet<K_SNI2007Grupp> K_SNI2007Grupps { get; set; }
        public DbSet<K_SNI2007HuvudGrupp> K_SNI2007HuvudGrupps { get; set; }
        public DbSet<K_SNI2007UnderGrupp> K_SNI2007UnderGrupps { get; set; }
        public DbSet<K_SNI2007DetaljGrupp> K_SNI2007DetaljGrupps { get; set; }
        public DbSet<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupps { get; set; }
        public DbSet<K_SNI2002UnderGrupp> K_SNI2002UnderGrupps { get; set; }

        public DbSet<H_SNI2007AktivitetsArtUtokad> H_SNI2007AktivitetsArtUtokads { get; set; }

        public DbSet<H_T_SNI2007Avdelning> H_T_SNI2007Avdelnings { get; set; }
        public DbSet<H_T_SNI2007DetaljGrupp> H_T_SNI2007DetaljGrupps { get; set; }
        public DbSet<H_T_SNI2007Grupp> H_T_SNI2007Grupps { get; set; }
        public DbSet<H_T_SNI2007HuvudGrupp> H_T_SNI2007HuvudGrupps { get; set; }
        public DbSet<H_T_SNI2007UnderGrupp> H_T_SNI2007UnderGrupps { get; set; }
        public DbSet<H_T_SNI2007Uppslag> H_T_SNI2007Uppslags { get; set; }

        public DbSet<T_SNI2007Avdelning> T_SNI2007Avdelnings { get; set; }
        public DbSet<T_SNI2007Uppslag> T_SNI2007Uppslags { get; set; }
        public DbSet<T_SNI2007HuvudGrupp> T_SNI2007HuvudGrupps { get; set; }
        public DbSet<T_SNI2007Grupp> T_SNI2007Grupps { get; set; }
        public DbSet<T_SNI2007UnderGrupp> T_SNI2007UnderGrupps { get; set; }
        public DbSet<T_SNI2007DetaljGrupp> T_SNI2007DetaljGrupps { get; set; }
        public DbSet<T_UppslagMiss> T_UppslagMisss { get; set; }
            
        public DbSet<TA_SNI2007Avdelning> TA_SNI2007Avdelnings { get; set; }
        public DbSet<TA_SNI2007HuvudGrupp> TA_SNI2007HuvudGrupps { get; set; }
        public DbSet<TA_SNI2007Grupp> TA_SNI2007Grupps { get; set; }
        public DbSet<TA_SNI2007UnderGrupp> TA_SNI2007UnderGrupps { get; set; }
        public DbSet<TA_SNI2007DetaljGrupp> TA_SNI2007DetaljGrupps { get; set; }

        public DbSet<AliasSokOrd> AliasSokOrds { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new K_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002DetaljGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002UnderGruppMap());
            
            modelBuilder.Configurations.Add(new H_SNI2007AktivitetsArtUtokadMap());

            modelBuilder.Configurations.Add(new H_T_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007UppslagMap());

            modelBuilder.Configurations.Add(new T_SNI2007UppslagMap());           
            modelBuilder.Configurations.Add(new T_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new T_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new T_UppslagMissMap());

            modelBuilder.Configurations.Add(new TA_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new TA_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007DetaljGruppMap());

            modelBuilder.Configurations.Add(new AliasSokOrdMap());
        }
    }
}
