﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.Business;
using SNIAdminServer.Model;

namespace SNIAdminServer.Presentation
{
   public class ListorPresentation
    {
       private SelectNivaAndUpdateBusiness _fdbIntSniBusiness = new SelectNivaAndUpdateBusiness();

       public List<Model.Aktivitetsart> GetAktivitetsArtByNiva(string niva)
       {
           return _fdbIntSniBusiness.GetAktivitetsArtByNiva(niva);
       }
    }
}
