﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.Business;
using SNIAdminServer.Model;

namespace SNIAdminServer.Presentation
{
    public class HanteraSokOrdPresentation
    {
        public List<Model.AliasSokOrd> GetAllaAliasSokOrd(string sokOrd)
        {
            var aliasSokOrd = new HanteraSokOrdBusiness();
            return aliasSokOrd.GetAllaAliasSokOrd(sokOrd);

        }
        
        public void DeleteAliasSokOrd(string[] aliasSokOrd)
        {
            List<Model.AliasSokOrd> aliasSokOrdList = new List<AliasSokOrd>();

            //flytta över arrayen till Lista
            for (int i = 0; i < aliasSokOrd.Count(); i++)
            {
                AliasSokOrd alias = new AliasSokOrd();
                alias.AliasSokOrd1 = aliasSokOrd[i];
                aliasSokOrdList.Add(alias);
            }

            var business = new HanteraSokOrdBusiness();
            business.DeleteAliasSokOrd(aliasSokOrdList);
        }

        public List<Model.RuleValidation>  AddAliasSokOrd(string aliasSokOrd, string sokOrd)
        {
            var business = new HanteraSokOrdBusiness();
            return business.AddAliasSokOrd(aliasSokOrd, sokOrd);

        }
        
        public List<Model.UppslagsMiss> GetAllaUppslagsMiss()
        {
            var uppslagsMiss = new HanteraSokOrdBusiness();
            var uppslagsMissList = uppslagsMiss.GetAllaUppslagsMiss();

            return uppslagsMissList;        
        }

        public void DeleteUppslagsMiss(string[] uppslagsMiss)
        {

            List<Model.T_UppslagMiss>  uppslagsMissList = new List<T_UppslagMiss>();

            //flytta över arrayen till Lista
            for (int i = 0; i < uppslagsMiss.Count(); i++)
            {
               T_UppslagMiss t_uppslagMiss = new T_UppslagMiss();
               t_uppslagMiss.UppslagMiss=  uppslagsMiss[i];
               uppslagsMissList.Add(t_uppslagMiss);
            }
            
            var hanteraSokOrd = new HanteraSokOrdBusiness();
            hanteraSokOrd.DeleteUppslagsMiss(uppslagsMissList);          
          
        }


        public void DeleteUppslagsMissAlla(string[] keepUppslagMissId)
        {
            List<string> keepUppslagsMissList = new List<string>();

            //flytta över arrayen till Lista
            for (int i = 0; i < keepUppslagMissId.Count(); i++)
            {
                string t_uppslagMiss = keepUppslagMissId[i]; //new T_UppslagMiss();
               // t_uppslagMiss.UppslagMiss = keepUppslagMissId[i];
                keepUppslagsMissList.Add(t_uppslagMiss);
            }

            var hanteraSokOrd = new HanteraSokOrdBusiness();
            hanteraSokOrd.DeleteUppslagsMissAlla(keepUppslagsMissList);    
        }


        public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag()
        {
            var hanteraSokOrd = new HanteraSokOrdBusiness();
           return  hanteraSokOrd.GetAllaSniUppslag();
        }

        public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag(string sokOrd)
        {
            var hanteraSokOrd = new HanteraSokOrdBusiness();
            return hanteraSokOrd.GetAllaSniUppslag(sokOrd);
        }
    }
}
