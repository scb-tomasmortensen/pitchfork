﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.Business;
using SNIAdminServer.Model;

namespace SNIAdminServer.Presentation
{
    public class SelectNivaAndUpdatePresentation
    {
        private SelectNivaAndUpdateBusiness _fdbIntSniBusiness = new SelectNivaAndUpdateBusiness();

        public List<Model.Aktivitetsart> GetAktivitetsArtByNiva(string niva)
        {
            return _fdbIntSniBusiness.GetAktivitetsArtByNiva(niva);
        }

        public List<Model.Rubriker> GetRubrikByNivaAndSNIkod(string SNIkod, string niva)
        {
            return _fdbIntSniBusiness.GetRubrikByNivaAndSNIkod(SNIkod, niva);
        }

        public List<Model.Omfattar> GetOmfattarByNivaSNIkodAndOmfTyp(string SNIkod, string niva, int OmfTypA, int OmfTypB)
        {
            return _fdbIntSniBusiness.GetOmfattarByNivaSNIkodAndOmfTyp(SNIkod, niva, OmfTypA, OmfTypB);
        }

        public List<Model.Allman> GetAllmanTextByNivaAndSNIkod(string SNIkod, string niva)
        {
            return _fdbIntSniBusiness.GetAllmanTextByNivaAndSNIkod(SNIkod, niva);
        }

        public List<Model.Niva> GetAllaNiva()
        {
                List<Niva> niva = new List<Niva>
            {
                new Niva { 
                    SNINiva = "Avdelning",
                    NivaId = "A"
                },
                 new Niva { 
                    SNINiva = "HuvudGrupp",
                     NivaId = "2"
                },
                 new Niva { 
                    SNINiva = "Grupp",
                     NivaId = "3"
                },
                 new Niva { 
                    SNINiva = "UnderGrupp",
                     NivaId = "4"
                },
                 new Niva { 
                    SNINiva = "DetaljGrupp",
                     NivaId = "5"
                }
            };
                return niva;
        }

        public List<Model.T_SNI2007Uppslag> GetUppslagsText(string SNIKod)
        {
            return _fdbIntSniBusiness.GetUppslagsText(SNIKod);
        }

        public List<Model.RuleValidationNiva> ValideraUppslagsText(string Text)
        {
            return _fdbIntSniBusiness.ValideraUppslagsText(Text);
        }

        public List<Model.RuleValidationNiva> ValideraUppslagKod(string NySNIKod)
        {
            return _fdbIntSniBusiness.ValideraUppslagKod(NySNIKod);
        }

        public List<Model.RuleValidationNiva> ValideraUppslag2002Kod(string SNI2002Kod)
        {
            return _fdbIntSniBusiness.ValideraUppslag2002Kod(SNI2002Kod);
        }

        public void UppdateraUppslagsText(short OrdNr, string SNIKod, string Text, byte RedKod, string anvandare)
        {
            _fdbIntSniBusiness.UppdateraUppslagsText(OrdNr, SNIKod, Text, RedKod, anvandare);
        }

        public void UppdateraUppslagKod(short OrdNr, string SNIKod, string NySNIKod, string anvandare)
        {
            _fdbIntSniBusiness.UppdateraUppslagKod(OrdNr, SNIKod, NySNIKod, anvandare);
        }

        public void UppdateraUppslagSNI2002Kod(short OrdNr, string SNIKod, string SNI2002Kod, string anvandare)
        {
            _fdbIntSniBusiness.UppdateraUppslagSNI2002Kod(OrdNr, SNIKod, SNI2002Kod,anvandare);
        }

        public void NyttUppslag(string SNIKod, string SNI2002Kod, string Text, string anvandare)
        {

            _fdbIntSniBusiness.NyttUppslag(SNIKod, SNI2002Kod, Text, anvandare);
        }
        
        public void DeleteUppslagsText(int OrdNr, string SNIKod, string anvandare)
        { 
            _fdbIntSniBusiness.DeleteUppslagsText(OrdNr, SNIKod, anvandare);
        }

        public void DeleteAllmanTextByNivaAndSNIkod(string SNIkod, string niva)
        {
            _fdbIntSniBusiness.DeleteAllmanTextByNivaAndSNIkod(SNIkod, niva);
        }

        public void UpdateAllmanTextByNivaAndSNIkod(string SNIkod, string niva, string allmanText, string anvandare)
        {
            _fdbIntSniBusiness.UpdateAllmanTextByNivaAndSNIkod(SNIkod, niva, allmanText, anvandare);
        }

        public void UpdateRubrikByNivaAndSNIkod(string SNIkod, string niva, string Aktivitetsart, string Bransch, string AktArtUtokad, string RedKod, string anvandare)
        {
            _fdbIntSniBusiness.UpdateRubrikByNivaAndSNIkod(SNIkod, niva, Aktivitetsart, Bransch, AktArtUtokad, RedKod, anvandare);
        }

        public List<Model.RuleValidationNiva> ValideraOmfattarInteSpecial(List<OmfattarInteSpecial> omfattarlist)
        {
            return _fdbIntSniBusiness.ValideraOmfattarInteSpecial(omfattarlist);
        }

        public void _UpdateOmfattarInteSpecial(List<OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string anvandare)
        {
            _fdbIntSniBusiness._UpdateOmfattarInteSpecial(omfattarlist, niva, SNIkod, OmfTyp, RedKod, anvandare);
        }

        
       
    }
}
