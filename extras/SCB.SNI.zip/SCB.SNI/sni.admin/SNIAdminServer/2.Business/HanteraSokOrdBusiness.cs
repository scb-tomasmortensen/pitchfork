﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.DataAccess;

namespace SNIAdminServer.Business
{
    public class HanteraSokOrdBusiness
    {

        private FDBIntSNI2007DataAccess _fdbIntSni = new FDBIntSNI2007DataAccess();

        public List<Model.AliasSokOrd> GetAllaAliasSokOrd(string sokOrd)
        {
            return _fdbIntSni.GetAllaAliasSokOrd(sokOrd);

        }

        public void DeleteAliasSokOrd(List<Model.AliasSokOrd> aliasSokOrdList)
        {

            _fdbIntSni.DeleteAliasSokOrd(aliasSokOrdList);
        }

        public List<Model.RuleValidation> AddAliasSokOrd(string aliasSokOrd, string sokOrd)
        {
            Model.AliasSokOrd aliasSokOrdItem = new Model.AliasSokOrd();

            aliasSokOrdItem.AliasSokOrd1 = aliasSokOrd;
            aliasSokOrdItem.SokOrd = sokOrd;
          
            List<Model.RuleValidation> issues = aliasSokOrdItem.GetRuleValidation(GetAllaSniUppslag(),  GetAllaAliasSokOrd(""));

            if (issues.Count!=  0)
            {
                return issues;
            }
            else 
            { 
                _fdbIntSni.AddAliasSokOrd(aliasSokOrd, sokOrd);
                return issues;
            }
        }


        public List<Model.UppslagsMiss> GetAllaUppslagsMiss()
        {
            var uppslagsMissList = _fdbIntSni.GetAllaUppslagsMiss();
            var uppslagsMissUppdeladList = new List<Model.UppslagsMiss>();
          

            foreach (var item in uppslagsMissList)
            {
                string[] splitUppslagsMiss = item.UppslagMiss.Split();
                uppslagsMissUppdeladList.Add(new Model.UppslagsMiss()
               {                    
                  UppslagMiss = item.UppslagMiss,
                   //dela upp fält uppslagsmiss i tre properties
                  Ord1 = GetSplitPart(0, splitUppslagsMiss),
                  Ord2 = GetSplitPart(1, splitUppslagsMiss),
                  Ord3 = GetSplitPart(2, splitUppslagsMiss),
                  Datum = item.Datum
                                      
               });                
            }
            
            return uppslagsMissUppdeladList;        
        }

        private string GetSplitPart(int index, string[] split)
        {          

            if (split.Count() > index )
            {
                if (index == 2)
                {
                    string ord = "";
                    //returnera resterande ord i Ord3
                    for (int i = 2; i < split.Count(); i++)
                    {
                        ord = ord + " " + split[i];
                    }

                    return ord;
                }
                else
                { 
                    return split[index];
                }
            }

            return "";
        }


        public void DeleteUppslagsMiss(List<Model.T_UppslagMiss> uppslagsMissList)
        {
            _fdbIntSni.DeleteUppslagsMiss(uppslagsMissList); 
        
        }

        public void DeleteUppslagsMissAlla(List<string> keepUppslagMissId)
        {
            _fdbIntSni.DeleteUppslagsMissAlla(keepUppslagMissId); 
        
        }

        public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag()
        {
            return _fdbIntSni.GetAllaSniUppslag();
        }

        public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag(string sokOrd)
        {
            return _fdbIntSni.GetAllaSniUppslag(sokOrd);
        }

    }
}
