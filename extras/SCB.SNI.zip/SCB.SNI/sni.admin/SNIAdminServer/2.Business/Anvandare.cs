﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SNIAdminServer.Business
{
    public static class Anvandare
    {
        //public static string GetLoggedOnUserName()
        //{
            
        //   string scbID = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        //    scbID = scbID.Replace("SCB\\", "");
        //    return scbID;
        //    //test with other user           
        //    //return "scbchkl";//scbid;
        //}

        
    }
}
