﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.DataAccess;
using System.Web;

namespace SNIAdminServer.Business
{
    public class SelectNivaAndUpdateBusiness
    {
        private FDBIntSNI2007DataAccess _fdbIntSni = new FDBIntSNI2007DataAccess();

        #region AllaNiva

        public List<Model.Aktivitetsart> GetAktivitetsArtByNiva(string niva)
        {
            switch (niva)
            {
                case "A":
                    return GetAktivitetsArtA();
                case "2":
                    return GetAktivitetsArt2();
                case "3":
                    return GetAktivitetsArt3();
                case "4":
                    return GetAktivitetsArt4();
                case "5":
                    return GetAktivitetsArt5(); 

                default:
                    break;
            }

            return null;
        }

        private List<Model.Aktivitetsart> GetAktivitetsArtA()
        {
            var nivaAndUpdate = new FDBIntSNI2007DataAccess();
            var dbLista = nivaAndUpdate.GetAllaNivaA();
            var nyLista = new List<Model.Aktivitetsart>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Aktivitetsart()
                {
                    Beskrivning = item.AktivitetsArt,
                    Kod = item.SNI2007Avdelning,
                    Niva = "A"
                });

            }
            return nyLista;
        }
        private List<Model.Aktivitetsart> GetAktivitetsArt2()
        {
            var nivaAndUpdate = new FDBIntSNI2007DataAccess();
            var dbLista = nivaAndUpdate.GetAllaNiva2();
            var nyLista = new List<Model.Aktivitetsart>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Aktivitetsart()
                {
                    Beskrivning = item.AktivitetsArt,
                    Kod = item.SNI2007HuvudGrupp,
                    Niva = "2"
                });

            }
            return nyLista;
        }
        private List<Model.Aktivitetsart> GetAktivitetsArt3()
        {
            var nivaAndUpdate = new FDBIntSNI2007DataAccess();
            var dbLista = nivaAndUpdate.GetAllaNiva3();
            var nyLista = new List<Model.Aktivitetsart>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Aktivitetsart()
                {
                    Beskrivning = item.AktivitetsArt,
                    Kod = item.SNI2007Grupp,
                    Niva = "3"
                });

            }
            return nyLista;
        }
        private List<Model.Aktivitetsart> GetAktivitetsArt4()
        {
            var nivaAndUpdate = new FDBIntSNI2007DataAccess();
            var dbLista = nivaAndUpdate.GetAllaNiva4();
            var nyLista = new List<Model.Aktivitetsart>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Aktivitetsart()
                {
                    Beskrivning = item.AktivitetsArt,
                    Kod = item.SNI2007UnderGrupp,
                    Niva = "4"
                });

            }
            return nyLista;
        }

        private List<Model.Aktivitetsart> GetAktivitetsArt5()
        {
            var nivaAndUpdate = new FDBIntSNI2007DataAccess();
            var dbLista = nivaAndUpdate.GetAllaNiva5();
            var nyLista = new List<Model.Aktivitetsart>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Aktivitetsart()
                {
                    Beskrivning = item.AktivitetsArt,
                    Kod = item.SNI2007DetaljGrupp,
                    Niva = "5"
                });

            }
            return nyLista;
        }
        #endregion
        
        #region Rubriker

        public List<Model.Rubriker> GetRubrikByNivaAndSNIkod(string SNIkod, string niva)
        {
            switch (niva)
            {
                case "A":
                    return GetRubrikNivaA(SNIkod);
                case "2":
                    return GetRubrikNiva2(SNIkod);
                case "3":
                    return GetRubrikNiva3(SNIkod);
                case "4":
                    return GetRubrikNiva4(SNIkod);
                case "5":
                    return GetRubrikNiva5(SNIkod);

                default:
                    break;
            }

            return null;
        }

        private List<Model.Rubriker> GetRubrikNivaA(string SNIkod)
        {
            var dbLista = _fdbIntSni.GetRubrikerNivaA(SNIkod);
            var nyLista = new List<Model.Rubriker>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Rubriker()
                {
                    Aktivitetsart = item.AktivitetsArt,
                    AktivitetsartUtokad = "",
                    Bransch = item.Bransch,
                    Niva = "A",
                    Kod = SNIkod
                });

            }
            return nyLista;
        }
        private List<Model.Rubriker> GetRubrikNiva2(string SNIkod)
        {
            var dbLista = _fdbIntSni.GetRubrikerNiva2(SNIkod);
            var nyLista = new List<Model.Rubriker>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Rubriker()
                {
                    Aktivitetsart = item.AktivitetsArt,
                    AktivitetsartUtokad = "",
                    Bransch = item.Bransch,
                    Niva = "2",
                    Kod = SNIkod
                });

            }
            return nyLista;
        }

        private List<Model.Rubriker> GetRubrikNiva3(string SNIkod)
        {
            var dbLista = _fdbIntSni.GetRubrikerNiva3(SNIkod);
            var nyLista = new List<Model.Rubriker>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Rubriker()
                {
                    Aktivitetsart = item.AktivitetsArt,
                    AktivitetsartUtokad = "",
                    Bransch = item.Bransch,
                    Niva = "3",
                    Kod = SNIkod
                });

            }
            return nyLista;
        }

        private List<Model.Rubriker> GetRubrikNiva4(string SNIkod)
        {
            var dbLista = _fdbIntSni.GetRubrikerNiva4(SNIkod);
            var nyLista = new List<Model.Rubriker>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Rubriker()
                {
                    Aktivitetsart = item.AktivitetsArt,
                    AktivitetsartUtokad = "",
                    Bransch = item.Bransch,
                    Niva = "4",
                    Kod = SNIkod
                });

            }
            return nyLista;
        }

        private List<Model.Rubriker> GetRubrikNiva5(string SNIkod)
        {
            var dbLista = _fdbIntSni.GetRubrikerNiva5(SNIkod);
            var nyLista = new List<Model.Rubriker>();

            foreach (var item in dbLista)
            {
                nyLista.Add(new Model.Rubriker()
                {
                    Aktivitetsart = item.AktivitetsArt,
                    AktivitetsartUtokad = item.AktivitetsArtUtokad,
                    Bransch = item.Bransch,
                    Niva = "5",
                    Kod = SNIkod
                });

            }
            return nyLista;
        }

        public void UpdateRubrikByNivaAndSNIkod(string SNIkod, string niva, string Aktivitetsart, string Bransch, string AktArtUtokad, string RedKod, string anvandare)
        {
            
            switch (niva)
            {
                case "A":
                    _fdbIntSni.UpdateRubrikNivaA(SNIkod,Aktivitetsart, Bransch);
                    break;
                case "2":
                    _fdbIntSni.UpdateRubrikNiva2(SNIkod, Aktivitetsart, Bransch);
                    break;
                case "3":
                    _fdbIntSni.UpdateRubrikNiva3(SNIkod, Aktivitetsart, Bransch);
                    break;
                case "4":
                    _fdbIntSni.UpdateRubrikNiva4(SNIkod, Aktivitetsart, Bransch);
                    break;
                case "5":
                    _fdbIntSni.UpdateRubrikNiva5(SNIkod, Aktivitetsart, Bransch, AktArtUtokad, RedKod, anvandare);
                    break;

                default:
                    break;
            }            
        }
       
        #endregion
        
        #region Omfattar

         public List<Model.Omfattar> GetOmfattarByNivaSNIkodAndOmfTyp(string SNIkod, string niva, int OmfTypA, int OmfTypB)
        {
            switch (niva)
            {
                case "A":
                    return GetOmfattarNivaA(SNIkod, OmfTypA, OmfTypB);
                case "2":
                    return GetOmfattarNiva2(SNIkod, OmfTypA, OmfTypB);
                case "3":
                    return GetOmfattarNiva3(SNIkod, OmfTypA, OmfTypB);
                case "4":
                    return GetOmfattarNiva4(SNIkod, OmfTypA, OmfTypB);
                case "5":
                    return GetOmfattarNiva5(SNIkod, OmfTypA, OmfTypB);

                default:
                    break;
            }

            return null;
        }
         public List<Model.RuleValidationNiva> ValideraOmfattarInteSpecial(List<Model.OmfattarInteSpecial> omfattarlist)
         {

             var ValideraLista = new List<Model.RuleValidationNiva>();

             foreach (var item in omfattarlist)
             {
                 //Kontrollera så att stycket inte är tomt
                 //if (string.IsNullOrEmpty(item.Value .Trim()))
                 if (item.Value == null || string.IsNullOrEmpty(item.Value.Trim()))
                 {
                     ValideraLista.Add(new Model.RuleValidationNiva()
                     {
                         ErrorMessage = "Värde saknas! Ingen uppdatering har gjorts.",
                         PropertyName = "",
                         PropertyValue = ""
                     });
                 }
             }

             return ValideraLista;
            
             
         
         }

         public void _UpdateOmfattarInteSpecial(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string anvandare)
         {

              switch (niva)
            {
                case "A":
                   _fdbIntSni.DeleteOmfattarNivaA(SNIkod, OmfTyp, anvandare);
                   if (omfattarlist != null)
                   {
                       _fdbIntSni.InsertOmfattarNivaA(omfattarlist, niva,SNIkod, OmfTyp, RedKod, anvandare);
                   }
                    break;
                case "2":
                    _fdbIntSni.DeleteOmfattarNiva2(SNIkod, OmfTyp, anvandare);
                    if (omfattarlist != null)
                    {
                        _fdbIntSni.InsertOmfattarNiva2(omfattarlist, niva,SNIkod, OmfTyp, RedKod, anvandare);
                    }
                    break;
                case "3":
                    _fdbIntSni.DeleteOmfattarNiva3(SNIkod, OmfTyp, anvandare);
                    if (omfattarlist != null)
                    {
                        _fdbIntSni.InsertOmfattarNiva3(omfattarlist, niva, SNIkod, OmfTyp, RedKod, anvandare);
                    }
                    break;
                case "4":
                    _fdbIntSni.DeleteOmfattarNiva4(SNIkod, OmfTyp, anvandare);
                    if (omfattarlist != null)
                    {
                        _fdbIntSni.InsertOmfattarNiva4(omfattarlist, niva, SNIkod, OmfTyp, RedKod, anvandare);
                    }
                    break;
                case "5":
                    _fdbIntSni.DeleteOmfattarNiva5(SNIkod, OmfTyp, anvandare);
                    if (omfattarlist != null)
                    {
                        _fdbIntSni.InsertOmfattarNiva5(omfattarlist, niva, SNIkod, OmfTyp, RedKod, anvandare);
                    }
                    break;
                default:
                    break;
            }  
          
        }
         

         private List<Model.Omfattar> GetOmfattarNivaA(string SNIkod, int OmfTypA, int OmfTypB)
         {
             var nivaAndUpdate = new FDBIntSNI2007DataAccess();
             var dbLista = nivaAndUpdate.GetOmfattarNivaA(SNIkod, OmfTypA, OmfTypB);
             var nyLista = new List<Model.Omfattar>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Omfattar()
                 {
                     Ord = item.OrdNr,
                     Stycke = item.DelText,
                     OmfTyp = item.OmfTyp,
                     Niva = "A",
                     SNIKod = item.SNI2007Avdelning,
                     
                 });

             }
             return nyLista;
         }

         private List<Model.Omfattar> GetOmfattarNiva2(string SNIkod, int OmfTypA, int OmfTypB)
         {
             var nivaAndUpdate = new FDBIntSNI2007DataAccess();
             var dbLista = nivaAndUpdate.GetOmfattarNiva2(SNIkod, OmfTypA, OmfTypB);
             var nyLista = new List<Model.Omfattar>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Omfattar()
                 {
                     Ord = item.OrdNr,
                     Stycke = item.DelText,
                     OmfTyp = item.OmfTyp,
                     Niva = "2",
                     SNIKod = item.SNI2007HuvudGrupp,
                 });

             }
             return nyLista;
         }

         private List<Model.Omfattar> GetOmfattarNiva3(string SNIkod, int OmfTypA, int OmfTypB)
         {
             var nivaAndUpdate = new FDBIntSNI2007DataAccess();
             var dbLista = nivaAndUpdate.GetOmfattarNiva3(SNIkod, OmfTypA, OmfTypB);
             var nyLista = new List<Model.Omfattar>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Omfattar()
                 {
                     Ord = item.OrdNr,
                     Stycke = item.DelText,
                     OmfTyp = item.OmfTyp,
                     Niva = "3",
                     SNIKod = item.SNI2007Grupp,
                 });

             }
             return nyLista;
         }

         private List<Model.Omfattar> GetOmfattarNiva4(string SNIkod, int OmfTypA, int OmfTypB)
         {
             var nivaAndUpdate = new FDBIntSNI2007DataAccess();
             var dbLista = nivaAndUpdate.GetOmfattarNiva4(SNIkod, OmfTypA, OmfTypB);
             var nyLista = new List<Model.Omfattar>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Omfattar()
                 {
                     Ord = item.OrdNr,
                     Stycke = item.DelText,
                     OmfTyp = item.OmfTyp,
                     Niva = "4",
                     SNIKod = item.SNI2007UnderGrupp,
                 });

             }
             return nyLista;
         }

         private List<Model.Omfattar> GetOmfattarNiva5(string SNIkod, int OmfTypA, int OmfTypB)
         {
             var nivaAndUpdate = new FDBIntSNI2007DataAccess();
             var dbLista = nivaAndUpdate.GetOmfattarNiva5(SNIkod, OmfTypA, OmfTypB);
             var nyLista = new List<Model.Omfattar>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Omfattar()
                 {
                     Ord = item.OrdNr,
                     Stycke = item.DelText,
                     OmfTyp = item.OmfTyp,
                     Niva = "5",
                     SNIKod = item.SNI2007DetaljGrupp,
                 });

             }
             return nyLista;
         }
            
        #endregion

        #region Uppslagstext

         public List<Model.T_SNI2007Uppslag> GetUppslagsText(string SNIkod)
         {
            
             var dbLista = _fdbIntSni.GetUppslag(SNIkod);

             return dbLista;

         }

         public List<Model.RuleValidationNiva> ValideraUppslagKod(string NySNIKod)
         {
             var ValideraLista = new List<Model.RuleValidationNiva>();

             //Börjar med att kontrollera så att koden inte är tom
             if (string.IsNullOrEmpty(NySNIKod.Trim()))
             {
                 //Texten finns för någon snikod, ingen uppdatering görs!
                 ValideraLista.Add(new Model.RuleValidationNiva()
                 {
                     ErrorMessage = "Fyll i ett värde! Ingen uppdatering har gjorts.",
                     PropertyName = "",
                     PropertyValue = ""
                 });
             }
             else
             {
                 //Kontrollerar så att koden är giltig, dvs finns tabellen K_SNI2002DetaljGrupp.
                 var SNIKod = _fdbIntSni.ValideraUppslagKod(NySNIKod);

                 if (SNIKod == null) //Koden finns inte i tabell.
                 {
                     //Koden finns inte, skicka felmeddelande.
                     ValideraLista.Add(new Model.RuleValidationNiva()
                     {
                         ErrorMessage = "Angiven SNI2007 kod finns inte i tabellen K_SNI2007DetaljGrupp. Ingen uppdatering har gjorts.",
                         PropertyName = "",
                         PropertyValue = ""
                     });
                 }

             }
             return ValideraLista;
         }


         public List<Model.RuleValidationNiva> ValideraUppslag2002Kod(string SNI2002Kod)
         {
             var ValideraLista = new List<Model.RuleValidationNiva>();

             //Börjar med att kontrollera så att koden inte är tom
             if (string.IsNullOrEmpty(SNI2002Kod.Trim()))
             {
                 //Texten finns för någon snikod, ingen uppdatering görs!
                 ValideraLista.Add(new Model.RuleValidationNiva()
                 {
                     ErrorMessage = "Fyll i ett värde! Ingen uppdatering har gjorts",
                     PropertyName = "",
                     PropertyValue = ""
                 });
             }
             else
             {
                 //Kontrollerar så att koden är giltig, dvs finns tabellen K_SNI2002DetaljGrupp.
                 var SNIKod2002 = _fdbIntSni.ValideraUppslag2002Kod(SNI2002Kod);


                 if (SNIKod2002 == null) //Koden finns inte i tabell.
                 {
                     //Koden finns inte, skicka felmeddelande.
                     ValideraLista.Add(new Model.RuleValidationNiva()
                     {
                         ErrorMessage = "Angiven SNI2002 kod finns inte i tabellen K_SNI2002DetaljGrupp. Ingen uppdatering har gjorts.",
                         PropertyName = "",
                         PropertyValue = ""
                     });
                 }
             }
             return ValideraLista;
         }



        public List<Model.RuleValidationNiva> ValideraUppslagsText(string Text)
         {
             var ValideraLista = new List<Model.RuleValidationNiva>();

            //Börjar med att kontrollera så att Texten inte är tom
             if (string.IsNullOrEmpty(Text.Trim()))
             {
                 //Texten finns för någon snikod, ingen uppdatering görs!
                ValideraLista.Add(new Model.RuleValidationNiva()
                {
                    ErrorMessage = "Fyll i ett värde! Ingen uppdatering har gjorts",
                    PropertyName = "",
                    PropertyValue = ""
                });
             }
             else
             {
                //Kontrollerar så att Uppslagstexten inte redan finns
                var uppslagsText = _fdbIntSni.ValideraUppslagsText(Text);
               
            
                if (uppslagsText == null) //Texten finns inte sedan tidigare, gå vidare med att kontrollera texten i Alias
                {
                    var uppslagsTextAlias = _fdbIntSni.ValideraUppslagsTextAlias(Text);
                    if (uppslagsTextAlias != null)
                    {
                        //Texten finns i Alias
                        ValideraLista.Add(new Model.RuleValidationNiva()
                        {
                            ErrorMessage = "alias",
                            PropertyName = uppslagsTextAlias.AliasSokOrd1,
                            PropertyValue = uppslagsTextAlias.SokOrd
                        });
                    }
                }
                else
                {
                    //Texten finns för någon snikod, ingen uppdatering görs!
                    ValideraLista.Add(new Model.RuleValidationNiva()
                    {
                        ErrorMessage = "Uppslagstexten finns redan för SNIkod " + uppslagsText.SNI2007DetaljGrupp + ", ingen uppdatering har gjorts",
                        PropertyName = uppslagsText.SNI2007DetaljGrupp,
                        PropertyValue = ""
                    });

                }

            }

             return ValideraLista;

         }

        public void UppdateraUppslagsText(short OrdNr, string SNIKod, string Text, byte RedKod, string anvandare)
         {

             _fdbIntSni.UppdateraUppslagsText(OrdNr, SNIKod, Text, anvandare, RedKod);
         }

        public void UppdateraUppslagKod(short OrdNr, string SNIKod, string NySNIKod, string anvandare)
         {

             _fdbIntSni.UppdateraUppslagKod(OrdNr, SNIKod, NySNIKod, anvandare);
         }

         public void UppdateraUppslagSNI2002Kod(short OrdNr, string SNIKod, string SNI2002Kod, string anvandare)
         {
             _fdbIntSni.UppdateraUppslagSNI2002Kod(OrdNr, SNIKod, SNI2002Kod, anvandare);
         }

         public void NyttUppslag(string SNIKod, string SNI2002Kod, string Text, string anvandare)
         {
             _fdbIntSni.NyttUppslag(SNIKod, SNI2002Kod, Text, anvandare);         
         }

         public void DeleteUppslagsText(int OrdNr, string SNIKod, string anvandare)
         {
             _fdbIntSni.DeleteUppslagsText(OrdNr, SNIKod, anvandare);
         }

         #endregion


        #region Allmantext

         public List<Model.Allman> GetAllmanTextByNivaAndSNIkod(string SNIkod, string niva)
         {
             switch (niva)
             {
                 case "A":
                     return GetAllmanTextNivaA(SNIkod);
                 case "2":
                     return GetAllmanTextNiva2(SNIkod);
                 case "3":
                     return GetAllmanTextNiva3(SNIkod);
                 case "4":
                     return GetAllmanTextNiva4(SNIkod);
                 case "5":
                     return GetAllmanTextNiva5(SNIkod);

                 default:
                     break;
             }

             return null;
         }

         private List<Model.Allman> GetAllmanTextNivaA(string SNIkod)
         {
            
             var dbLista = _fdbIntSni.GetAllmanTextA(SNIkod);
             var nyLista = new List<Model.Allman>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Allman()
                 {
                     AllmanText = item.AllmanText, 
                     Niva = "A",
                     SNIKod = SNIkod,
                 });

             }
             return nyLista;
         }

         private List<Model.Allman> GetAllmanTextNiva2(string SNIkod)
         {
             var dbLista = _fdbIntSni.GetAllmanText2(SNIkod);
             var nyLista = new List<Model.Allman>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Allman()
                 {
                     AllmanText = item.AllmanText,
                     Niva = "2",
                     SNIKod = SNIkod,
                 });

             }
             return nyLista;
         }

         private List<Model.Allman> GetAllmanTextNiva3(string SNIkod)
         {
             var dbLista = _fdbIntSni.GetAllmanText3(SNIkod);
             var nyLista = new List<Model.Allman>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Allman()
                 {
                     AllmanText = item.AllmanText,
                     Niva = "3",
                     SNIKod = SNIkod,
                 });

             }
             return nyLista;
         }

         private List<Model.Allman> GetAllmanTextNiva4(string SNIkod)
         {
             var dbLista = _fdbIntSni.GetAllmanText4(SNIkod);
             var nyLista = new List<Model.Allman>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Allman()
                 {
                     AllmanText = item.AllmanText,
                     Niva = "4",
                     SNIKod = SNIkod,
                 });

             }
             return nyLista;
         }

         private List<Model.Allman> GetAllmanTextNiva5(string SNIkod)
         {
             var dbLista = _fdbIntSni.GetAllmanText5(SNIkod);
             var nyLista = new List<Model.Allman>();

             foreach (var item in dbLista)
             {
                 nyLista.Add(new Model.Allman()
                 {
                     AllmanText = item.AllmanText,
                     Niva = "5",
                     SNIKod = SNIkod,
                 });

             }
             return nyLista;
         }

         public void UpdateAllmanTextByNivaAndSNIkod(string SNIkod, string niva, string AllmanText, string anvandare)
         {

             switch (niva)
             {
                 case "A":
                     _fdbIntSni.UpdateAllmanTextNivaA(SNIkod, AllmanText, anvandare);
                     break;
                 case "2":
                     _fdbIntSni.UpdateAllmanTextNiva2(SNIkod, AllmanText, anvandare);
                     break;
                 case "3":
                     _fdbIntSni.UpdateAllmanTextNiva3(SNIkod, AllmanText, anvandare);
                     break;
                 case "4":
                     _fdbIntSni.UpdateAllmanTextNiva4(SNIkod, AllmanText, anvandare);
                     break;
                 case "5":
                     _fdbIntSni.UpdateAllmanTextNiva5(SNIkod, AllmanText, anvandare);
                     break;

                 default:
                     break;
             }
         }

         public void DeleteAllmanTextByNivaAndSNIkod(string SNIkod, string niva)
         {
             
             switch (niva)
             {
                 case "A":
                     _fdbIntSni.DeleteAllmanTextNivaA(SNIkod);
                     break;
                 case "2":
                     _fdbIntSni.DeleteAllmanTextNiva2(SNIkod);
                     break;
                 case "3":
                     _fdbIntSni.DeleteAllmanTextNiva3(SNIkod);
                     break;
                 case "4":
                     _fdbIntSni.DeleteAllmanTextNiva4(SNIkod);
                     break;
                 case "5":
                     _fdbIntSni.DeleteAllmanTextNiva5(SNIkod);
                     break;

                 default:
                     break;
             }
         }



        #endregion


    }
}
