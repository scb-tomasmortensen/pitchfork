﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.DataAccess
{
    public class FDBIntSNI2007DataAccess
    {
        private FDBIntSniContext _context;

        public FDBIntSNI2007DataAccess()
        {
            _context = new FDBIntSniContext();        
        }

        public List<Model.Niva> GetNiva(string niva)
        {
            throw new NotImplementedException();
        }


        #region Uppslagsmiss

            public List<Model.T_UppslagMiss> GetAllaUppslagsMiss()
            {
               //Hämta alla uppslagsmissar
                List<Model.T_UppslagMiss> uppslagsMiss = _context.T_UppslagMisss.OrderBy(x => x.Datum).ToList();

                return uppslagsMiss;     
            }

            //Radera alla uppslagsmissar förutom de i listan keepUppslagsMissList
            public void DeleteUppslagsMissAlla(List<string> keepUppslagsMissList)
            {
                var allaUppslagsMiss = (from c in _context.T_UppslagMisss
                                        where !keepUppslagsMissList.Contains(c.UppslagMiss)
                                                           select c).ToList();

             
                _context.T_UppslagMisss.RemoveRange(allaUppslagsMiss);
                _context.SaveChanges();
                          
            }


     
            public void DeleteUppslagsMiss(List<Model.T_UppslagMiss> uppslagsMissList)
            {
                foreach (var item in uppslagsMissList)
                {

                    var uppslagsMiss = (from miss in _context.T_UppslagMisss
                                        where miss.UppslagMiss == item.UppslagMiss                                  
                                        select miss).FirstOrDefault();

                    if (uppslagsMiss != null)
                    {
                        _context.T_UppslagMisss.Remove(uppslagsMiss);
                    
                    }
                                     
                    
                }
                _context.SaveChanges();
            }

        #endregion

        #region SniUppslag

            public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag()
            {
                //Hämta alla aliassökord
                List<Model.T_SNI2007Uppslag> sniUppslag = _context.T_SNI2007Uppslags.ToList();

                return sniUppslag;
            }


            public List<Model.T_SNI2007Uppslag> GetAllaSniUppslag(string sokOrd)
            {
                //splitta sokOrd        
                string[] words = sokOrd.ToUpper().Split(' ');

               
                //Hämta alla aliassökord
                List<Model.T_SNI2007Uppslag> sniUppslag = _context.T_SNI2007Uppslags.Where(x => words.All(w => x.UppslagText.Contains(w))).ToList();


             //   List<Model.T_SNI2007Uppslag> sniUppslag = _context.T_SNI2007Uppslags.Where(x=>x.UppslagText.ToUpper().Contains(sokOrd.ToUpper())).ToList();

                return sniUppslag;
            }

        #endregion

        #region AliasSokOrd

            public List<Model.AliasSokOrd> GetAllaAliasSokOrd()
            {
                //Hämta alla aliassökord
                List<Model.AliasSokOrd> aliasSokOrd = _context.AliasSokOrds.ToList();

                return aliasSokOrd;
            }


            public List<Model.AliasSokOrd> GetAllaAliasSokOrd(string sokOrd)
            {
                List<Model.AliasSokOrd> aliasSokOrd;
                if (sokOrd == "")
                {
                    //Hämta alla aliassökord
                    aliasSokOrd = _context.AliasSokOrds.ToList();
                }
                else
                {
                    //filtrera
                    aliasSokOrd = _context.AliasSokOrds.Where(x => x.AliasSokOrd1.Contains(sokOrd)).ToList();
                }
                return aliasSokOrd;
            }
          
            public void DeleteAliasSokOrd(List<Model.AliasSokOrd > aliasSokOrdList)
            {
                foreach (var item in aliasSokOrdList)
                {
                    var aliasSokOrd = (from alias in _context.AliasSokOrds
                                       where alias.AliasSokOrd1 == item.AliasSokOrd1
                                       select alias).FirstOrDefault();

                    if (aliasSokOrd != null)
                    {
                        _context.AliasSokOrds.Remove(aliasSokOrd);

                    }
                
                }
                _context.SaveChanges();
            }


            public void AddAliasSokOrd(string aliasSokOrd, string sokOrd)
            {
               Model.AliasSokOrd aliasSokOrdItem = new Model.AliasSokOrd();

                aliasSokOrdItem.AliasSokOrd1= aliasSokOrd;
                aliasSokOrdItem.SokOrd = sokOrd;

               _context.AliasSokOrds.Add(aliasSokOrdItem);
               _context.SaveChanges();

            }

        #endregion

        #region AllaNiva
        //Hämtar alla nivåer (kod, aktivitesart)
        // på viss nivå, bestämt av vilken nivå som är markerad och lägger ut data.      
        public List<Model.K_SNI2007Avdelning> GetAllaNivaA()
        {
            //Hämtar allt på niva A
            List<Model.K_SNI2007Avdelning> AllaNivaA = _context.K_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning != "").ToList();

            return AllaNivaA;           

        }

        public List<Model.K_SNI2007HuvudGrupp> GetAllaNiva2()
        {
            //Hämtar allt på niva 2         
            List<Model.K_SNI2007HuvudGrupp> AllaNiva2 = _context.K_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp != "00").ToList();

            return AllaNiva2;
        }

        public List<Model.K_SNI2007Grupp> GetAllaNiva3()
        {
            //Hämtar allt på niva 3    
            List<Model.K_SNI2007Grupp> AllaNiva3 = _context.K_SNI2007Grupps.Where(x => x.SNI2007Grupp != "000").ToList();

            return AllaNiva3;
        }

        public List<Model.K_SNI2007UnderGrupp> GetAllaNiva4()
        {
            //Hämtar allt på niva 4          
            List<Model.K_SNI2007UnderGrupp> AllaNiva4 = _context.K_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp != "0000").ToList();

            return AllaNiva4;
        }

        public List<Model.K_SNI2007DetaljGrupp> GetAllaNiva5()
        {
            //Hämtar allt på nivå 5          
            List<Model.K_SNI2007DetaljGrupp> AllaNiva5 = _context.K_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp != "00000").ToList();

            return AllaNiva5;

        }
        #endregion

        #region Rubriker
        //Hämtar alla rubriker (kod, aktivitesart och bransch)
        // på viss nivå, bestämt av vilken nivå och SNIkod som är markerad och lägger ut data.      
        public List<Model.K_SNI2007Avdelning> GetRubrikerNivaA(string SNIkod)
        {
            //Hämtar på niva A
            List<Model.K_SNI2007Avdelning> RubrikerNivaA = _context.K_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIkod).ToList();

            return RubrikerNivaA;

        }

        public List<Model.K_SNI2007HuvudGrupp> GetRubrikerNiva2(string SNIkod)
        {
            //Hämtar på niva 2         
            List<Model.K_SNI2007HuvudGrupp> RubrikerNiva2 = _context.K_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIkod).ToList();

            return RubrikerNiva2;
        }

        public List<Model.K_SNI2007Grupp> GetRubrikerNiva3(string SNIkod)
        {
            //Hämtar allt på niva 3    
            List<Model.K_SNI2007Grupp> RubrikerNiva3 = _context.K_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIkod).ToList();

            return RubrikerNiva3;
        }

        public List<Model.K_SNI2007UnderGrupp> GetRubrikerNiva4(string SNIkod)
        {
            //Hämtar på niva 4          
            List<Model.K_SNI2007UnderGrupp> RubrikerNiva4 = _context.K_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIkod).ToList();

            return RubrikerNiva4;
        }

        public List<Model.K_SNI2007DetaljGrupp> GetRubrikerNiva5(string SNIkod)
        {
            //Hämtar på nivå 5          
            List<Model.K_SNI2007DetaljGrupp> RubrikerNiva5 = _context.K_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIkod).ToList();

            return RubrikerNiva5;

        }

        public void UpdateRubrikNivaA(string SNIKod, string Aktivitetsart, string Bransch)
        {
            _context.K_SNI2007Avdelnings.First(x => x.SNI2007Avdelning == SNIKod).AktivitetsArt = Aktivitetsart;
            _context.K_SNI2007Avdelnings.First(x => x.SNI2007Avdelning == SNIKod).Bransch = Bransch;
            
            _context.SaveChanges();
        }

        public void UpdateRubrikNiva2(string SNIKod, string Aktivitetsart, string Bransch)
        {
            _context.K_SNI2007HuvudGrupps.First(x => x.SNI2007HuvudGrupp == SNIKod).AktivitetsArt = Aktivitetsart;
            _context.K_SNI2007HuvudGrupps.First(x => x.SNI2007HuvudGrupp == SNIKod).Bransch = Bransch;

            _context.SaveChanges();
        }

        public void UpdateRubrikNiva3(string SNIKod, string Aktivitetsart, string Bransch)
        {
            _context.K_SNI2007Grupps.First(x => x.SNI2007Grupp == SNIKod).AktivitetsArt = Aktivitetsart;
            _context.K_SNI2007Grupps.First(x => x.SNI2007Grupp == SNIKod).Bransch = Bransch;

            _context.SaveChanges();
        }

        public void UpdateRubrikNiva4(string SNIKod, string Aktivitetsart, string Bransch)
        {
            _context.K_SNI2007UnderGrupps.First(x => x.SNI2007UnderGrupp == SNIKod).AktivitetsArt = Aktivitetsart;
            _context.K_SNI2007UnderGrupps.First(x => x.SNI2007UnderGrupp == SNIKod).Bransch = Bransch;

            _context.SaveChanges();
        }

        public void UpdateRubrikNiva5(string SNIKod, string Aktivitetsart, string Bransch, string AktArtUtokad, string RedKod, string Anvandare)
        {
            //Här finns också en historisk tabell som skall uppdateras (H_SNI2007AktivitetsArtUtokad), 
            //sker endast på nivå 5 om RedKod = 1 (Innehållsförändring) och om förändring skett i AktArtUtokad.
            if (RedKod == "1")
            {
                var histlist = _context.K_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod && x.AktivitetsArtUtokad.ToLower().Trim() == AktArtUtokad.ToLower().Trim()).ToList();
                if (histlist.Count == 0)
                {
                    //uppdatera H_SNI2007AktivitetsArtUtokad 

                    var hist = new Model.H_SNI2007AktivitetsArtUtokad 
                    {   SNI2007DetaljGrupp = SNIKod,
                        AktivitetsArtUtokad = AktArtUtokad,
                        SlutDatum = DateTime.Now,
                        UserId =  Anvandare
                    };
                        _context.H_SNI2007AktivitetsArtUtokads.Add(hist);
                        _context.SaveChanges();                
                }
            }

            _context.K_SNI2007DetaljGrupps.First(x => x.SNI2007DetaljGrupp == SNIKod).AktivitetsArt = Aktivitetsart;
            _context.K_SNI2007DetaljGrupps.First(x => x.SNI2007DetaljGrupp == SNIKod).Bransch = Bransch;
            _context.K_SNI2007DetaljGrupps.First(x => x.SNI2007DetaljGrupp == SNIKod).AktivitetsArtUtokad = AktArtUtokad;

            _context.SaveChanges();
        }




        #endregion

        #region Omfattar/OmfattarÄven
        //Hämtar Omfattar/=mfattaräven texter (Ord, Stycke)
        // på viss nivå, bestämt av vilken nivå och SNIkod som är markerad samt OmfattarTyp och lägger ut data.      
        public List<Model.T_SNI2007Avdelning> GetOmfattarNivaA(string SNIkod, int OmfTypA, int OmfTypB)
        {
            //Hämtar på niva A
            List<Model.T_SNI2007Avdelning> OmfattarNivaA = _context.T_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIkod && (x.OmfTyp == OmfTypA || x.OmfTyp == OmfTypB)).OrderBy(x => x.OmfTyp).ToList();

            return OmfattarNivaA;
        }

        public List<Model.T_SNI2007HuvudGrupp> GetOmfattarNiva2(string SNIkod, int OmfTypA, int OmfTypB)
        {
            //Hämtar på niva 2         
            List<Model.T_SNI2007HuvudGrupp> OmfattarNiva2 = _context.T_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIkod && (x.OmfTyp == OmfTypA || x.OmfTyp == OmfTypB)).OrderBy(x => x.OmfTyp).ToList();

            return OmfattarNiva2;
        }

        public List<Model.T_SNI2007Grupp> GetOmfattarNiva3(string SNIkod, int OmfTypA, int OmfTypB)
        {
            //Hämtar på niva 3    
            List<Model.T_SNI2007Grupp> OmfattarNiva3 = _context.T_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIkod && (x.OmfTyp == OmfTypA || x.OmfTyp == OmfTypB)).OrderBy(x => x.OmfTyp).ToList();

            return OmfattarNiva3;
        }

        public List<Model.T_SNI2007UnderGrupp> GetOmfattarNiva4(string SNIkod, int OmfTypA, int OmfTypB)
        {
            //Hämtar på niva 4          
            List<Model.T_SNI2007UnderGrupp> OmfattarNiva4 = _context.T_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIkod && (x.OmfTyp == OmfTypA || x.OmfTyp == OmfTypB)).OrderBy(x => x.OmfTyp).ToList();

            return OmfattarNiva4;
        }

        public List<Model.T_SNI2007DetaljGrupp> GetOmfattarNiva5(string SNIkod, int OmfTypA, int OmfTypB)
        {
            //Hämtar på nivå 5          
            List<Model.T_SNI2007DetaljGrupp> OmfattarNiva5 = _context.T_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIkod && (x.OmfTyp == OmfTypA || x.OmfTyp == OmfTypB)).OrderBy(x => x.OmfTyp).ToList();

            return OmfattarNiva5;
        }

        public void DeleteOmfattarNiva5(string SNIKod, byte OmfTyp, string Anvandare)
        {
            //Kopierar de gamla raderna till historiska och tömmer den aktuella
            //för denna snikod och omfattartyp. 

            var list = _context.T_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod && x.OmfTyp == OmfTyp).ToList();
                if (list.Count != 0)
                {
                    //insert H_T_SNI2007DetaljGrupp
                    foreach (var item in list)
	                {
		                var hist = new Model.H_T_SNI2007DetaljGrupp
                        {
                            SNI2007DetaljGrupp = SNIKod,
                            OmfTyp = OmfTyp,
                            StartDat = item.BearbDat,
                            SlutDat = DateTime.Now,
                            OrdNr = item.OrdNr,
                            DelText = item.DelText,
                            RedigeringKod = item.RedigeringKod,
                            UserId = item.UserId
                        };
                        _context.H_T_SNI2007DetaljGrupps.Add(hist);
                        
	                }
                    
                    _context.SaveChanges();

                    //Tar bort raderna i T_SNI2007DetaljGrupp
                    foreach (var item in list)
                    {
                        _context.T_SNI2007DetaljGrupps.Remove(item);   
                    }

                    _context.SaveChanges();
                    
                }
            
        }

        public void InsertOmfattarNiva5(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string Anvandare)
        {
            //Gör en insert med de nya raderna.

            //insert T_SNI2007DetaljGrupp
            foreach (var item in omfattarlist)
            {
                var list = new Model.T_SNI2007DetaljGrupp
                {
                    SNI2007DetaljGrupp = SNIkod,
                    OmfTyp = OmfTyp,
                    OrdNr =  Convert.ToInt16(omfattarlist.IndexOf(item) + 1),
                    DelText = item.Value,
                    BearbDat = DateTime.Now,
                    RedigeringKod = RedKod,
                    UserId = Anvandare
                };
                _context.T_SNI2007DetaljGrupps.Add(list);

            }

            _context.SaveChanges();
        }

        public void DeleteOmfattarNiva4(string SNIKod, byte OmfTyp, string Anvandare)
        {
            //Kopierar de gamla raderna till historiska och tömmer den aktuella
            //för denna snikod och omfattartyp. 

            var list = _context.T_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIKod && x.OmfTyp == OmfTyp).ToList();
            if (list.Count != 0)
            {
                //insert H_T_SNI2007UnderGrupp
                foreach (var item in list)
                {
                    var hist = new Model.H_T_SNI2007UnderGrupp
                    {
                        SNI2007UnderGrupp = SNIKod,
                        OmfTyp = OmfTyp,
                        StartDat = item.BearbDat,
                        SlutDat = DateTime.Now,
                        OrdNr = item.OrdNr,
                        DelText = item.DelText,
                        RedigeringKod = item.RedigeringKod,
                        UserId = item.UserId
                    };
                    _context.H_T_SNI2007UnderGrupps.Add(hist);

                }

                _context.SaveChanges();

                //Tar bort raderna i T_SNI2007DetaljGrupp
                foreach (var item in list)
                {
                    _context.T_SNI2007UnderGrupps.Remove(item);
                }

                _context.SaveChanges();

            }

        }

        public void InsertOmfattarNiva4(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string Anvandare)
        {
            //Gör en insert med de nya raderna.

            //insert T_SNI2007UnderGrupp
            foreach (var item in omfattarlist)
            {
                var list = new Model.T_SNI2007UnderGrupp
                {
                    SNI2007UnderGrupp = SNIkod,
                    OmfTyp = OmfTyp,
                    OrdNr = Convert.ToInt16(omfattarlist.IndexOf(item) + 1),
                    DelText = item.Value,
                    BearbDat = DateTime.Now,
                    RedigeringKod = RedKod,
                    UserId = Anvandare
                };
                _context.T_SNI2007UnderGrupps.Add(list);

            }

            _context.SaveChanges();
        }

        public void DeleteOmfattarNiva3(string SNIKod, byte OmfTyp, string Anvandare)
        {
            //Kopierar de gamla raderna till historiska och tömmer den aktuella
            //för denna snikod och omfattartyp. 

            var list = _context.T_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIKod && x.OmfTyp == OmfTyp).ToList();
            if (list.Count != 0)
            {
                //insert H_T_SNI2007Grupp
                foreach (var item in list)
                {
                    var hist = new Model.H_T_SNI2007Grupp
                    {
                        SNI2007Grupp = SNIKod,
                        OmfTyp = OmfTyp,
                        StartDat = item.BearbDat,
                        SlutDat = DateTime.Now,
                        OrdNr = item.OrdNr,
                        DelText = item.DelText,
                        RedigeringKod = item.RedigeringKod,
                        UserId = item.UserId
                    };
                    _context.H_T_SNI2007Grupps.Add(hist);

                }

                _context.SaveChanges();

                //Tar bort raderna i T_SNI2007Grupp
                foreach (var item in list)
                {
                    _context.T_SNI2007Grupps.Remove(item);
                }

                _context.SaveChanges();

            }

        }

        public void InsertOmfattarNiva3(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string Anvandare)
        {
            //Gör en insert med de nya raderna.

            //insert T_SNI2007Grupp
            foreach (var item in omfattarlist)
            {
                var list = new Model.T_SNI2007Grupp
                {
                    SNI2007Grupp = SNIkod,
                    OmfTyp = OmfTyp,
                    OrdNr = Convert.ToInt16(omfattarlist.IndexOf(item) + 1),
                    DelText = item.Value,
                    BearbDat = DateTime.Now,
                    RedigeringKod = RedKod,
                    UserId = Anvandare
                };
                _context.T_SNI2007Grupps.Add(list);

            }

            _context.SaveChanges();
        }

        public void DeleteOmfattarNiva2(string SNIKod, byte OmfTyp, string Anvandare)
        {
            //Kopierar de gamla raderna till historiska och tömmer den aktuella
            //för denna snikod och omfattartyp. 

            var list = _context.T_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIKod && x.OmfTyp == OmfTyp).ToList();
            if (list.Count != 0)
            {
                //insert H_T_SNI2007HuvudGrupp
                foreach (var item in list)
                {
                    var hist = new Model.H_T_SNI2007HuvudGrupp
                    {
                        SNI2007HuvudGrupp = SNIKod,
                        OmfTyp = OmfTyp,
                        StartDat = item.BearbDat,
                        SlutDat = DateTime.Now,
                        OrdNr = item.OrdNr,
                        DelText = item.DelText,
                        RedigeringKod = item.RedigeringKod,
                        UserId = item.UserId
                    };
                    _context.H_T_SNI2007HuvudGrupps.Add(hist);

                }

                _context.SaveChanges();

                //Tar bort raderna i T_SNI2007HuvudGrupp
                foreach (var item in list)
                {
                    _context.T_SNI2007HuvudGrupps.Remove(item);
                }

                _context.SaveChanges();

            }

        }

        public void InsertOmfattarNiva2(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string Anvandare)
        {
            //Gör en insert med de nya raderna.

            //insert T_SNI2007HuvudGrupp
            foreach (var item in omfattarlist)
            {
                var list = new Model.T_SNI2007HuvudGrupp
                {
                    SNI2007HuvudGrupp = SNIkod,
                    OmfTyp = OmfTyp,
                    OrdNr = Convert.ToInt16(omfattarlist.IndexOf(item) + 1),
                    DelText = item.Value,
                    BearbDat = DateTime.Now,
                    RedigeringKod = RedKod,
                    UserId = Anvandare
                };
                _context.T_SNI2007HuvudGrupps.Add(list);

            }

            _context.SaveChanges();
        }

        public void DeleteOmfattarNivaA(string SNIKod, byte OmfTyp, string Anvandare)
        {
            //Kopierar de gamla raderna till historiska och tömmer den aktuella
            //för denna snikod och omfattartyp. 

            var list = _context.T_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIKod && x.OmfTyp == OmfTyp).ToList();
            if (list.Count != 0)
            {
                //insert H_T_SNI2007Avdelning
                foreach (var item in list)
                {
                    var hist = new Model.H_T_SNI2007Avdelning
                    {
                        SNI2007Avdelning = SNIKod,
                        OmfTyp = OmfTyp,
                        StartDat = item.BearbDat,
                        SlutDat = DateTime.Now,
                        OrdNr = item.OrdNr,
                        DelText = item.DelText,
                        RedigeringKod = item.RedigeringKod,
                        UserId = item.UserId
                    };
                    _context.H_T_SNI2007Avdelnings.Add(hist);

                }

                _context.SaveChanges();

                //Tar bort raderna i T_SNI2007Avdelning
                foreach (var item in list)
                {
                    _context.T_SNI2007Avdelnings.Remove(item);
                }
               
                _context.SaveChanges();

            }

        }

        public void InsertOmfattarNivaA(List<Model.OmfattarInteSpecial> omfattarlist, string niva, string SNIkod, byte OmfTyp, byte RedKod, string Anvandare)
        {
            //Gör en insert med de nya raderna.

            //insert T_SNI2007Avdelning
            foreach (var item in omfattarlist)
            {
                var list = new Model.T_SNI2007Avdelning
                {
                    SNI2007Avdelning = SNIkod,
                    OmfTyp = OmfTyp,
                    OrdNr = Convert.ToInt16(omfattarlist.IndexOf(item) + 1),
                    DelText = item.Value,
                    BearbDat = DateTime.Now,
                    RedigeringKod = RedKod,
                    UserId = Anvandare
                };
                _context.T_SNI2007Avdelnings.Add(list);

            }

            _context.SaveChanges();
        }


        #endregion

        #region Uppslagstext
        //Hämtar Uppslagstext för den Detaljgrupp (endast på 5-siffer-kod!) som är markerad och lägger in data i fliken "Uppslagstext"

        public List<Model.T_SNI2007Uppslag> GetUppslag(string SNIKod)
        {
            //Hämtar Uppslagstext för markerad SNI_kod, endast på 5-siffer nivå!
            List<Model.T_SNI2007Uppslag> uppslag = _context.T_SNI2007Uppslags.Where(x => x.SNI2007DetaljGrupp == SNIKod).ToList();

            return uppslag;

        }


        public Model.K_SNI2002DetaljGrupp ValideraUppslag2002Kod(string SNI2002Kod)
        {
            //Kontrollerar så att SNI2002Koden finns i tabellen K_SNI2002DetaljGrupp!
            var uppslag = _context.K_SNI2002DetaljGrupps.Where(x => x.SNI2002DetaljGrupp == SNI2002Kod).FirstOrDefault();

            return uppslag;

        }

        public Model.K_SNI2007DetaljGrupp ValideraUppslagKod(string SNIKod)
        {
            //Kontrollerar så att SNIKoden finns i tabellen K_SNI2007DetaljGrupp!
            var uppslag = _context.K_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod).FirstOrDefault();

            return uppslag;

        }

        public Model.T_SNI2007Uppslag ValideraUppslagsText(string Text)
        {
            //Kontrollerar så att Uppslagstexten inte redan finns, om den finns returnera snikod och ordnr!
            var uppslag = _context.T_SNI2007Uppslags.Where(x => x.UppslagText == Text).FirstOrDefault();

            return uppslag;

        }

        public Model.AliasSokOrd ValideraUppslagsTextAlias(string Text)
        {
            //Kontrollerar så att Uppslagstexten inte redan finns, om den finns returnera snikod och ordnr!
            var alias = _context.AliasSokOrds.Where(x => x.AliasSokOrd1.Equals(Text)).FirstOrDefault();

            return alias;

        }

        public void UppdateraUppslagKod(short OrdNr, string SNIKod, string NySNIKod, string anvandare)
        {
            //Uppdaterar endast SNIKoden för Uppslag. 

            //Hämtar den gamla raden i T_SNI2007Uppslag.
            var UppslagsRad = _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr);
           
            //Hämta nytt OrdNr  
            var NewOrdNr = OrdningsNr(NySNIKod);

            //Den nya raden läggs till i T_SNI2007Uppslag, INSERT
            var nyradUppslag = new Model.T_SNI2007Uppslag
            {
                SNI2007DetaljGrupp = NySNIKod,
                OrdNr = Convert.ToInt16(NewOrdNr),                
                RedigeringKod = 1,
                UppslagKod = 3,
                UppslagText = UppslagsRad.UppslagText,
                BearbDat = DateTime.Now,
                UserId = UppslagsRad.UserId,
                SNIxxxx = UppslagsRad.SNIxxxx
            };
            _context.T_SNI2007Uppslags.Add(nyradUppslag);
            _context.SaveChanges();

            //Tar bort den gamla raden. Den historiska tabellen ska uppdateras innan delete! Allt detta görs i DeleteUppslagsText nedan.  
            DeleteUppslagsText(OrdNr, SNIKod, anvandare);


        }
        public void NyttUppslag(string SNIKod, string SNI2002Kod, string Text, string anvandare)
        {

            //Hämta nytt OrdNr  
            var NewOrdNr = OrdningsNr(SNIKod);

            //Den nya raden läggs till i T_SNI2007Uppslag, INSERT
            var nyradUppslag = new Model.T_SNI2007Uppslag
            {
                SNI2007DetaljGrupp = SNIKod,
                OrdNr = Convert.ToInt16(NewOrdNr),
                RedigeringKod = 1,
                UppslagKod = 1,
                UppslagText = Text,
                BearbDat = DateTime.Now,
                UserId = anvandare,
                SNIxxxx = SNI2002Kod
            };
            _context.T_SNI2007Uppslags.Add(nyradUppslag);
            _context.SaveChanges();
        
        }

        public int OrdningsNr(string NySNIKod)
        {
            //Hämtar Max OrdNr, returnerar det OrdNr som ska sparas
            int MaxOrdNr = 0;
            int NewOrdNr = 0;

            //Hämtar max ordnr i tabellen  T_SNI2007Uppslag. Sätts till 0 om SNIkoden ej finns i tabellen
            var OrdNrUppslag = 0;
            var Uppslag = _context.T_SNI2007Uppslags.Where(x => x.SNI2007DetaljGrupp == NySNIKod).ToList();
            if (Uppslag.Count != 0)
            {
               OrdNrUppslag = _context.T_SNI2007Uppslags.Where(x => x.SNI2007DetaljGrupp == NySNIKod).Max(y => y.OrdNr);                
            }
            //Hämtar max ordnr i tabellen  H_T_SNI2007Uppslag. Sätts till 0 om SNIkoden ej finns i tabellen
            var OrdnrUppslagHist = 0;
            var Hist = _context.H_T_SNI2007Uppslags.Where(x => x.SNI2007DetaljGrupp == NySNIKod).ToList();
            if (Hist.Count != 0)
            {
                OrdnrUppslagHist = _context.H_T_SNI2007Uppslags.Where(x => x.SNI2007DetaljGrupp == NySNIKod).Max(y => y.OrdNr);
            }
           
           //Det största OrdNr fastställs.
            if (OrdNrUppslag > OrdnrUppslagHist)
            {
                MaxOrdNr = OrdNrUppslag;
            }
            else
            {
                MaxOrdNr = OrdnrUppslagHist;
            }
            
            //Returnera Nya OrdNr 
            NewOrdNr = MaxOrdNr + 1;

                return NewOrdNr;

        }

        public void UppdateraUppslagsText(short OrdNr, string SNIKod, string Text,  string anvandare, byte RedKod)
        {
            //Uppdaterar endast Texten för Uppslag. 
            //Den historiska tabellen ska även uppdateras! H_T_SNI2007Uppslag  


            //Hämtar aktuell rad.
            var AktuellRad = _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr);
           
            //Sparar först raden i den historiska tabellen: H_T_SNI2007Uppslag 
            var hist = new Model.H_T_SNI2007Uppslag
            {
                SNI2007DetaljGrupp = AktuellRad.SNI2007DetaljGrupp,
                OrdNr = OrdNr,
                StartDat = AktuellRad.BearbDat,
                SlutDat = DateTime.Now,
                RedigeringKod = AktuellRad.RedigeringKod,
                UppslagKod = AktuellRad.UppslagKod,
                UppslagText = AktuellRad.UppslagText,
                UserId = AktuellRad.UserId
            };
            _context.H_T_SNI2007Uppslags.Add(hist);
            _context.SaveChanges();
            
                    
            
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).UppslagText = Text;
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).UppslagKod = 2; //Sätts hårt i gamla proceduren... 1 vid insert
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).UserId = anvandare;
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).RedigeringKod = RedKod;
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).BearbDat = DateTime.Now;

         
        
            _context.SaveChanges();
        }

        public void UppdateraUppslagSNI2002Kod(short OrdNr, string SNIKod, string SNI2002Kod, string anvandare)
        {
            //Uppdaterar endast SNI2002 för Uppslag. 

            //Hämtar aktuell rad.
            var AktuellRad = _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr);

            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).SNIxxxx = SNI2002Kod;
            _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr).UserId = anvandare;

            _context.SaveChanges();
        }


        public void DeleteUppslagsText(int OrdNr, string SNIKod, string anvandare)
        {
            // Den historiska tabellen uppdateras innan borttag, H_T_SNI2007Uppslag
            
            var rad = _context.T_SNI2007Uppslags.First(x => x.SNI2007DetaljGrupp == SNIKod && x.OrdNr == OrdNr);
            //uppdatera H_SNI2007AktivitetsArtUtokad 

            var hist = new Model.H_T_SNI2007Uppslag
            {
                SNI2007DetaljGrupp = rad.SNI2007DetaljGrupp,
                OrdNr = rad.OrdNr,
                StartDat = rad.BearbDat,
                SlutDat = DateTime.Now,
                RedigeringKod = rad.RedigeringKod,
                UppslagKod = 9,
                UppslagText = rad.UppslagText,
                UserId = anvandare
            };
            _context.H_T_SNI2007Uppslags.Add(hist);
            _context.SaveChanges();                


            _context.T_SNI2007Uppslags.Remove(rad);     
            _context.SaveChanges();
        }

        #endregion
        
        #region Allmantext
        //Hämtar AllmanTexten, dvs en text i någon av tabellerna TA_SNI2007xxxx från vald Niva och SNIkod
        public List<Model.TA_SNI2007Avdelning> GetAllmanTextA(string SNIKod)
        {

            List<Model.TA_SNI2007Avdelning> AllmanTextA = _context.TA_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIKod).ToList();

            return AllmanTextA;            

        }

        public List<Model.TA_SNI2007HuvudGrupp> GetAllmanText2(string SNIKod)
        {

            List<Model.TA_SNI2007HuvudGrupp> AllmanText2 = _context.TA_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIKod).ToList();

            return AllmanText2;    

        }
        public List<Model.TA_SNI2007Grupp> GetAllmanText3(string SNIKod)
        {

            List<Model.TA_SNI2007Grupp> AllmanText3 = _context.TA_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIKod).ToList();

            return AllmanText3;    

        }
        public List<Model.TA_SNI2007UnderGrupp> GetAllmanText4(string SNIKod)
        {

            List<Model.TA_SNI2007UnderGrupp> AllmanText4 = _context.TA_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIKod).ToList();

            return AllmanText4;    

        }
        public List<Model.TA_SNI2007DetaljGrupp> GetAllmanText5(string SNIKod)
        {

            List<Model.TA_SNI2007DetaljGrupp> AllmanText5 = _context.TA_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod).ToList();

            return AllmanText5;    

        }
        public void UpdateAllmanTextNivaA(string SNIKod, string allmanText, string Anvandare)
        {

            var list = _context.TA_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIKod).ToList();
             if (list.Count == 0) //Gör insert om det ej finns någon rad sedan tidigare.
             {

                 var nylist = new Model.TA_SNI2007Avdelning
                 {
                     SNI2007Avdelning = SNIKod,
                     AllmanText = allmanText,
                     BearbDat = DateTime.Now,
                     UserId = Anvandare
                 };
                 _context.TA_SNI2007Avdelnings.Add(nylist);
             
             }
             else//uppdatering av befintlig Allmäntext.
             {
                 _context.TA_SNI2007Avdelnings.First(x => x.SNI2007Avdelning == SNIKod).AllmanText = allmanText;        
             }

            _context.SaveChanges();
        }
        public void UpdateAllmanTextNiva2(string SNIKod, string allmanText, string Anvandare)
        {
            var list = _context.TA_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIKod).ToList();
            if (list.Count == 0) //Gör insert om det ej finns någon rad sedan tidigare.
            {
                var nylist = new Model.TA_SNI2007HuvudGrupp
                {
                    SNI2007HuvudGrupp = SNIKod,
                    AllmanText = allmanText,
                    BearbDat = DateTime.Now,
                    UserId = Anvandare
                };
                _context.TA_SNI2007HuvudGrupps.Add(nylist);

            }
            else//uppdatering av befintlig Allmäntext.
            {
                _context.TA_SNI2007HuvudGrupps.First(x => x.SNI2007HuvudGrupp == SNIKod).AllmanText = allmanText;
            }

            _context.SaveChanges();
        }

        public void UpdateAllmanTextNiva3(string SNIKod, string allmanText, string Anvandare)
        {
            var list = _context.TA_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIKod).ToList();
            if (list.Count == 0) //Gör insert om det ej finns någon rad sedan tidigare.
            {
                var nylist = new Model.TA_SNI2007Grupp
                {
                    SNI2007Grupp = SNIKod,
                    AllmanText = allmanText,
                    BearbDat = DateTime.Now,
                    UserId = Anvandare
                };
                _context.TA_SNI2007Grupps.Add(nylist);

            }
            else//uppdatering av befintlig Allmäntext.
            {
                _context.TA_SNI2007Grupps.First(x => x.SNI2007Grupp == SNIKod).AllmanText = allmanText;
            }

            _context.SaveChanges();
        }

        public void UpdateAllmanTextNiva4(string SNIKod, string allmanText, string Anvandare)
        {
            var list = _context.TA_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIKod).ToList();
            if (list.Count == 0) //Gör insert om det ej finns någon rad sedan tidigare.
            {
                var nylist = new Model.TA_SNI2007UnderGrupp
                {
                    SNI2007UnderGrupp = SNIKod,
                    AllmanText = allmanText,
                    BearbDat = DateTime.Now,
                    UserId = Anvandare
                };
                _context.TA_SNI2007UnderGrupps.Add(nylist);

            }
            else//uppdatering av befintlig Allmäntext.
            {
                _context.TA_SNI2007UnderGrupps.First(x => x.SNI2007UnderGrupp == SNIKod).AllmanText = allmanText;
            }

            _context.SaveChanges();
        }

        public void UpdateAllmanTextNiva5(string SNIKod, string allmanText, string Anvandare)
        {
            var list = _context.TA_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod).ToList();
            if (list.Count == 0) //Gör insert om det ej finns någon rad sedan tidigare.
            {
                var nylist = new Model.TA_SNI2007DetaljGrupp
                {
                    SNI2007DetaljGrupp = SNIKod,
                    AllmanText = allmanText,
                    BearbDat = DateTime.Now,
                    UserId = Anvandare
                };
                _context.TA_SNI2007DetaljGrupps.Add(nylist);

            }

            else//uppdatering av befintlig Allmäntext.
            {
                _context.TA_SNI2007DetaljGrupps.First(x => x.SNI2007DetaljGrupp == SNIKod).AllmanText = allmanText;
            }

            _context.SaveChanges();
        }
        public void DeleteAllmanTextNivaA(string SNIKod)
        {
            var item = _context.TA_SNI2007Avdelnings.Where(x => x.SNI2007Avdelning == SNIKod).FirstOrDefault();
            if (item != null) //Gör delete om det finns någon rad sedan tidigare.
            {
                _context.TA_SNI2007Avdelnings.Remove(item);
                _context.SaveChanges();
            }
        }
        public void DeleteAllmanTextNiva2(string SNIKod)
        {
            var item = _context.TA_SNI2007HuvudGrupps.Where(x => x.SNI2007HuvudGrupp == SNIKod).FirstOrDefault();
            if (item != null) //Gör delete om det finns någon rad sedan tidigare.
            {
                _context.TA_SNI2007HuvudGrupps.Remove(item);
                _context.SaveChanges();
            }
        }
        public void DeleteAllmanTextNiva3(string SNIKod)
        {
            var item = _context.TA_SNI2007Grupps.Where(x => x.SNI2007Grupp == SNIKod).FirstOrDefault();
            if (item != null) //Gör delete om det finns någon rad sedan tidigare.
            {
                _context.TA_SNI2007Grupps.Remove(item);
                _context.SaveChanges();
            }
        }
        public void DeleteAllmanTextNiva4(string SNIKod)
        {
            var item = _context.TA_SNI2007UnderGrupps.Where(x => x.SNI2007UnderGrupp == SNIKod).FirstOrDefault();
            if (item != null) //Gör delete om det finns någon rad sedan tidigare.
            {
                _context.TA_SNI2007UnderGrupps.Remove(item);
                _context.SaveChanges();
            }
        }
        public void DeleteAllmanTextNiva5(string SNIKod)
        {
            var item = _context.TA_SNI2007DetaljGrupps.Where(x => x.SNI2007DetaljGrupp == SNIKod).FirstOrDefault();
            if (item != null) //Gör delete om det finns någon rad sedan tidigare.
            {
                _context.TA_SNI2007DetaljGrupps.Remove(item);
                _context.SaveChanges();
            }
        }

        #endregion
    }
}

