using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class TA_SNI2007HuvudGrupp
    {
        public string SNI2007HuvudGrupp { get; set; }
        public string AllmanText { get; set; }
        public System.DateTime BearbDat { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007HuvudGrupp K_SNI2007HuvudGrupp { get; set; }
    }
}
