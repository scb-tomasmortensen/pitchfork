using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class H_T_SNI2007UnderGrupp
    {
        public string SNI2007UnderGrupp { get; set; }
        public byte OmfTyp { get; set; }
        public System.DateTime StartDat { get; set; }
        public System.DateTime SlutDat { get; set; }
        public short OrdNr { get; set; }
        public string DelText { get; set; }
        public byte RedigeringKod { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007UnderGrupp K_SNI2007UnderGrupp { get; set; }
    }
}
