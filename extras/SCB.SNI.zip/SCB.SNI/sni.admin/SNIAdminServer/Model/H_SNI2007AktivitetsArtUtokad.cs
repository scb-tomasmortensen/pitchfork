using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class H_SNI2007AktivitetsArtUtokad
    {
        public string SNI2007DetaljGrupp { get; set; }
        public System.DateTime SlutDatum { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007DetaljGrupp K_SNI2007DetaljGrupp { get; set; }
    }
}
