﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SNIAdminServer.DataAccess;

namespace SNIAdminServer.Model
{
    public partial class AliasSokOrd : IRuleEntity 
    {

        public List<RuleValidation> GetRuleValidation()
        {
            return new List<RuleValidation>();
        
        }

        public List<RuleValidation> GetRuleValidation(List<Model.T_SNI2007Uppslag> sni2007UppslagList, List<Model.AliasSokOrd> aliasSokOrdList)
        {
            List<RuleValidation> validationIssues = new List<RuleValidation>();
            bool uppslagContainsAliasSokOrd;
            bool uppslagContainsSokOrd;


            if (AliasSokOrd1.Trim() == "")
            {
                validationIssues.Add(new RuleValidation ("alias", AliasSokOrd1, "Alias sökord får ej vara tom"));

            }

            if (AliasSokOrd1.Contains(" "))
            {
                
             validationIssues.Add(new RuleValidation ("alias", AliasSokOrd1, "Alias sökord får ej innehålla mellanslag"));
            }
                      
            

            if (SokOrd.Trim()  == "")
            {
                validationIssues.Add(new RuleValidation("sokord", SokOrd, "Sökord får ej vara tom"));

            }

            if (SokOrd.Contains(" "))
            {

                validationIssues.Add(new RuleValidation("sokord", SokOrd, "Sökord får ej innehålla mellanslag"));
            }


            //kontroll mot sni2007Uppslag när de andra kollerna är OK
            if (validationIssues.Count == 0)
            {
             
                uppslagContainsSokOrd = sni2007UppslagList.Any(x => x.UppslagText.ToUpper().Contains(SokOrd.ToUpper()));
                uppslagContainsAliasSokOrd = sni2007UppslagList.Any(x => !x.UppslagText.ToUpper().Contains(AliasSokOrd1.ToUpper()));
              

                if (uppslagContainsAliasSokOrd && uppslagContainsSokOrd)
                {
                    
                    if( aliasSokOrdList.Any(x=> x.AliasSokOrd1.ToUpper().Equals(AliasSokOrd1.ToUpper())))
                    {

                        validationIssues.Add(new RuleValidation("alias", AliasSokOrd1, "Alias sökord får inte finnas som AliasSokOrd i tabellen AliasSokOrd"));

                    }
                }
                else if (sni2007UppslagList.Any(x => x.UppslagText.ToUpper().Contains(AliasSokOrd1.ToUpper())))
                {

                    validationIssues.Add(new RuleValidation("alias", AliasSokOrd1, "Alias sökord får inte finnas i Uppslagtext i tabellen T_SNI2007Uppslag"));

                }

                else
                {
                    validationIssues.Add(new RuleValidation("sokord", SokOrd, "Sökord måste finnas i Uppslagtext i tabellen T_SNI2007Uppslag"));

                }

            }

            return validationIssues;
        }
           

    }
}
