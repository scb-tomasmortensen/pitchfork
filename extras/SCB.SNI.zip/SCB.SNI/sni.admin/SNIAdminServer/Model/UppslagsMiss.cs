﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class UppslagsMiss
    {
        public string UppslagMiss { get; set; }
        public System.DateTime Datum { get; set; }
        public string Ord1 { get; set; }
        public string Ord2 { get; set; }
        public string Ord3 { get; set; }

    }
}
