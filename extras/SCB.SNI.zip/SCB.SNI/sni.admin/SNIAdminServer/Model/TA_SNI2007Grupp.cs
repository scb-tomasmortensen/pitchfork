using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class TA_SNI2007Grupp
    {
        public string SNI2007Grupp { get; set; }
        public string AllmanText { get; set; }
        public System.DateTime BearbDat { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007Grupp K_SNI2007Grupp { get; set; }
    }
}
