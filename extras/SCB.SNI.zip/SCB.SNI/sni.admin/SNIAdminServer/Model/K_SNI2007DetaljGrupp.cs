﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class K_SNI2007DetaljGrupp
    {

        public string SNI2007DetaljGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string Bransch { get; set; }
        public string SNI2007UnderGrupp { get; set; }


        public virtual K_SNI2007UnderGrupp K_SNI2007UnderGrupp { get; set; }
        public virtual ICollection<T_SNI2007DetaljGrupp> T_SNI2007DetaljGrupp { get; set; }
        public virtual ICollection<T_SNI2007Uppslag> T_SNI2007Uppslag { get; set; }
        public virtual TA_SNI2007DetaljGrupp TA_SNI2007DetaljGrupp { get; set; }
        public virtual ICollection<H_SNI2007AktivitetsArtUtokad> H_SNI2007AktivitetsArtUtokad { get; set; }
        public virtual ICollection<H_T_SNI2007Uppslag> H_T_SNI2007Uppslag { get; set; }
        public virtual ICollection<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupp { get; set; }
        public virtual ICollection<H_T_SNI2007DetaljGrupp> H_T_SNI2007DetaljGrupp { get; set; }
       
        

    }

   
}
