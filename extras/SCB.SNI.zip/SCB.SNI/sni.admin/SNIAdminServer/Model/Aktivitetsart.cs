﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class Aktivitetsart
    {
        public string Kod { get; set; }
        public string Beskrivning { get; set; }
        public string Niva { get; set; }
    }
}
