using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class TA_SNI2007UnderGrupp
    {
        public string SNI2007UnderGrupp { get; set; }
        public string AllmanText { get; set; }
        public System.DateTime BearbDat { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007UnderGrupp K_SNI2007UnderGrupp { get; set; }
    }
}
