﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class K_SNI2007Grupp
    {
        public string SNI2007Grupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007HuvudGrupp { get; set; }

        public virtual K_SNI2007HuvudGrupp K_SNI2007HuvudGrupp { get; set; }
        public virtual ICollection<K_SNI2007UnderGrupp> K_SNI2007UnderGrupp { get; set; }
        public virtual ICollection<T_SNI2007Grupp> T_SNI2007Grupp { get; set; }
        public virtual TA_SNI2007Grupp TA_SNI2007Grupp { get; set; }
        public virtual ICollection<H_T_SNI2007Grupp> H_T_SNI2007Grupp { get; set; }
    }
}
