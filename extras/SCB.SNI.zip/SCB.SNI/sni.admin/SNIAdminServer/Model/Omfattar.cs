﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class Omfattar
    {
        public int Ord  { get; set; }
        public string Stycke { get; set; }
        public int OmfTyp { get; set; }
        public string Niva { get; set; }
        public string SNIKod { get; set; }
        


       
    }
}
