﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{

    public partial class AliasSokOrd  
    {
        public string AliasSokOrd1 { get; set; }
        public string SokOrd { get; set; }

        
    }
}
