﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class Rubriker
    {
        public string Aktivitetsart { get; set; }
        public string AktivitetsartUtokad { get; set; }
        public string Bransch { get; set; }
        public string Niva { get; set; }
        public string Kod { get; set; }
       
    }
}
