﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class Niva
    {
        public string SNINiva { get; set; }
        public string NivaId { get; set; }
    }
}
