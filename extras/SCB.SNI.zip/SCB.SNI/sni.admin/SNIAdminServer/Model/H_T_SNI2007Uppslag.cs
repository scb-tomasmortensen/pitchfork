using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public partial class H_T_SNI2007Uppslag
    {
        public string SNI2007DetaljGrupp { get; set; }
        public short OrdNr { get; set; }
        public System.DateTime StartDat { get; set; }
        public System.DateTime SlutDat { get; set; }
        public byte RedigeringKod { get; set; }
        public byte UppslagKod { get; set; }
        public string UppslagText { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2007DetaljGrupp K_SNI2007DetaljGrupp { get; set; }
    }
}
