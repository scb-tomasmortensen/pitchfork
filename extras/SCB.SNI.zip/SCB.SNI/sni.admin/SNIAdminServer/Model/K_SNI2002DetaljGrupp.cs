using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class K_SNI2002DetaljGrupp
    {
       

        public string SNI2002DetaljGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string Bransch { get; set; }
        public string SNI2002UnderGrupp { get; set; }
        //public virtual ICollection<H_SNI2002AktivitetsArtUtokad> H_SNI2002AktivitetsArtUtokad { get; set; }
        //public virtual ICollection<H_T_SNI2002DetaljGrupp> H_T_SNI2002DetaljGrupp { get; set; }
        //public virtual ICollection<H_T_SNI2002Uppslag> H_T_SNI2002Uppslag { get; set; }
        //public virtual K_SNI2002UnderGrupp K_SNI2002UnderGrupp { get; set; }
        //public virtual ICollection<T_SNI2002DetaljGrupp> T_SNI2002DetaljGrupp { get; set; }
        //public virtual ICollection<T_SNI2002Uppslag> T_SNI2002Uppslag { get; set; }
        public virtual K_SNI2002UnderGrupp K_SNI2002UnderGrupp { get; set; }
        public virtual ICollection<T_SNI2007Uppslag> T_SNI2007Uppslag { get; set; }
        //public virtual TA_SNI2002DetaljGrupp TA_SNI2002DetaljGrupp { get; set; }
        public virtual ICollection<K_SNI2007DetaljGrupp> K_SNI2007DetaljGrupp { get; set; }
        //public virtual ICollection<K_SNI92DetaljGrupp> K_SNI92DetaljGrupp { get; set; }
    }
}
