﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SNIAdminServer.Model
{
    public class Allman
    {
        public string AllmanText { get; set; }
        public string Niva { get; set; }
        public string SNIKod { get; set; }
    }
}
