using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007GruppEng
    {
        public K_SNI2007GruppEng()
        {
            this.K_SNI2007UnderGruppEng = new List<K_SNI2007UnderGruppEng>();
        }

        public string SNI2007Grupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007HuvudGrupp { get; set; }
        public virtual K_SNI2007HuvudGruppEng K_SNI2007HuvudGruppEng { get; set; }
        public virtual ICollection<K_SNI2007UnderGruppEng> K_SNI2007UnderGruppEng { get; set; }
    }
}
