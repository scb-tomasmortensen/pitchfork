using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007HuvudGruppEng
    {
        public K_SNI2007HuvudGruppEng()
        {
            this.K_SNI2007GruppEng = new List<K_SNI2007GruppEng>();
        }

        public string SNI2007HuvudGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007Avdelning { get; set; }
        public virtual K_SNI2007AvdelningEng K_SNI2007AvdelningEng { get; set; }
        public virtual ICollection<K_SNI2007GruppEng> K_SNI2007GruppEng { get; set; }
    }
}
