using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007HuvudGrupp
    {
        public K_SNI2007HuvudGrupp()
        {
            this.H_T_SNI2007HuvudGrupp = new List<H_T_SNI2007HuvudGrupp>();
            this.K_SNI2007Grupp = new List<K_SNI2007Grupp>();
            this.T_SNI2007HuvudGrupp = new List<T_SNI2007HuvudGrupp>();
        }

        public string SNI2007HuvudGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007Avdelning { get; set; }
        public virtual ICollection<H_T_SNI2007HuvudGrupp> H_T_SNI2007HuvudGrupp { get; set; }
        public virtual K_SNI2007Avdelning K_SNI2007Avdelning { get; set; }
        public virtual ICollection<K_SNI2007Grupp> K_SNI2007Grupp { get; set; }
        public virtual ICollection<T_SNI2007HuvudGrupp> T_SNI2007HuvudGrupp { get; set; }
        public virtual TA_SNI2007HuvudGrupp TA_SNI2007HuvudGrupp { get; set; }
    }
}
