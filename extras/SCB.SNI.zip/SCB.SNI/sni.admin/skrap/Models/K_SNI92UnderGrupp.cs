using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92UnderGrupp
    {
        public K_SNI92UnderGrupp()
        {
            this.K_SNI92DetaljGrupp = new List<K_SNI92DetaljGrupp>();
        }

        public string SNI92UnderGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI92Grupp { get; set; }
        public virtual ICollection<K_SNI92DetaljGrupp> K_SNI92DetaljGrupp { get; set; }
        public virtual K_SNI92Grupp K_SNI92Grupp { get; set; }
    }
}
