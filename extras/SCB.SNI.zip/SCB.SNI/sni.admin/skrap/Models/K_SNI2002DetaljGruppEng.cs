using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002DetaljGruppEng
    {
        public string SNI2002DetaljGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002UnderGrupp { get; set; }
        public virtual K_SNI2002UnderGruppEng K_SNI2002UnderGruppEng { get; set; }
    }
}
