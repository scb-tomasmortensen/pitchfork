using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007UnderGrupp
    {
        public K_SNI2007UnderGrupp()
        {
            this.H_T_SNI2007UnderGrupp = new List<H_T_SNI2007UnderGrupp>();
            this.K_SNI2007DetaljGrupp = new List<K_SNI2007DetaljGrupp>();
            this.T_SNI2007UnderGrupp = new List<T_SNI2007UnderGrupp>();
        }

        public string SNI2007UnderGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007Grupp { get; set; }
        public virtual ICollection<H_T_SNI2007UnderGrupp> H_T_SNI2007UnderGrupp { get; set; }
        public virtual ICollection<K_SNI2007DetaljGrupp> K_SNI2007DetaljGrupp { get; set; }
        public virtual K_SNI2007Grupp K_SNI2007Grupp { get; set; }
        public virtual ICollection<T_SNI2007UnderGrupp> T_SNI2007UnderGrupp { get; set; }
        public virtual TA_SNI2007UnderGrupp TA_SNI2007UnderGrupp { get; set; }
    }
}
