using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class S_SNIAnv2007
    {
        public string UserId { get; set; }
        public string SNI2007 { get; set; }
    }
}
