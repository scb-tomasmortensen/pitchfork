using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using skrap.Models.Mapping;

namespace skrap.Models
{
    public partial class FDBIntSniContext : DbContext
    {
        static FDBIntSniContext()
        {
            Database.SetInitializer<FDBIntSniContext>(null);
        }

        public FDBIntSniContext()
            : base("Name=FDBIntSniContext")
        {
        }

        public DbSet<AliasSokOrd> AliasSokOrds { get; set; }
        public DbSet<dtproperty> dtproperties { get; set; }
        public DbSet<H_SNI2002AktivitetsArtUtokad> H_SNI2002AktivitetsArtUtokad { get; set; }
        public DbSet<H_SNI2007AktivitetsArtUtokad> H_SNI2007AktivitetsArtUtokad { get; set; }
        public DbSet<H_T_SNI2002Avdelning> H_T_SNI2002Avdelning { get; set; }
        public DbSet<H_T_SNI2002DetaljGrupp> H_T_SNI2002DetaljGrupp { get; set; }
        public DbSet<H_T_SNI2002Grupp> H_T_SNI2002Grupp { get; set; }
        public DbSet<H_T_SNI2002HuvudGrupp> H_T_SNI2002HuvudGrupp { get; set; }
        public DbSet<H_T_SNI2002UnderAvdelning> H_T_SNI2002UnderAvdelning { get; set; }
        public DbSet<H_T_SNI2002UnderGrupp> H_T_SNI2002UnderGrupp { get; set; }
        public DbSet<H_T_SNI2002Uppslag> H_T_SNI2002Uppslag { get; set; }
        public DbSet<H_T_SNI2007Avdelning> H_T_SNI2007Avdelning { get; set; }
        public DbSet<H_T_SNI2007DetaljGrupp> H_T_SNI2007DetaljGrupp { get; set; }
        public DbSet<H_T_SNI2007Grupp> H_T_SNI2007Grupp { get; set; }
        public DbSet<H_T_SNI2007HuvudGrupp> H_T_SNI2007HuvudGrupp { get; set; }
        public DbSet<H_T_SNI2007UnderGrupp> H_T_SNI2007UnderGrupp { get; set; }
        public DbSet<H_T_SNI2007Uppslag> H_T_SNI2007Uppslag { get; set; }
        public DbSet<K_SNI2002Avdelning> K_SNI2002Avdelning { get; set; }
        public DbSet<K_SNI2002AvdelningEng> K_SNI2002AvdelningEng { get; set; }
        public DbSet<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupp { get; set; }
        public DbSet<K_SNI2002DetaljGruppEng> K_SNI2002DetaljGruppEng { get; set; }
        public DbSet<K_SNI2002Grupp> K_SNI2002Grupp { get; set; }
        public DbSet<K_SNI2002GruppEng> K_SNI2002GruppEng { get; set; }
        public DbSet<K_SNI2002HuvudGrupp> K_SNI2002HuvudGrupp { get; set; }
        public DbSet<K_SNI2002HuvudGruppEng> K_SNI2002HuvudGruppEng { get; set; }
        public DbSet<K_SNI2002UnderAvdelning> K_SNI2002UnderAvdelning { get; set; }
        public DbSet<K_SNI2002UnderAvdelningEng> K_SNI2002UnderAvdelningEng { get; set; }
        public DbSet<K_SNI2002UnderGrupp> K_SNI2002UnderGrupp { get; set; }
        public DbSet<K_SNI2002UnderGruppEng> K_SNI2002UnderGruppEng { get; set; }
        public DbSet<K_SNI2007Avdelning> K_SNI2007Avdelning { get; set; }
        public DbSet<K_SNI2007AvdelningEng> K_SNI2007AvdelningEng { get; set; }
        public DbSet<K_SNI2007DetaljGrupp> K_SNI2007DetaljGrupp { get; set; }
        public DbSet<K_SNI2007DetaljGruppEng> K_SNI2007DetaljGruppEng { get; set; }
        public DbSet<K_SNI2007Grupp> K_SNI2007Grupp { get; set; }
        public DbSet<K_SNI2007GruppEng> K_SNI2007GruppEng { get; set; }
        public DbSet<K_SNI2007HuvudGrupp> K_SNI2007HuvudGrupp { get; set; }
        public DbSet<K_SNI2007HuvudGruppEng> K_SNI2007HuvudGruppEng { get; set; }
        public DbSet<K_SNI2007UnderGrupp> K_SNI2007UnderGrupp { get; set; }
        public DbSet<K_SNI2007UnderGruppEng> K_SNI2007UnderGruppEng { get; set; }
        public DbSet<K_SNI92Avdelning> K_SNI92Avdelning { get; set; }
        public DbSet<K_SNI92DetaljGrupp> K_SNI92DetaljGrupp { get; set; }
        public DbSet<K_SNI92Grupp> K_SNI92Grupp { get; set; }
        public DbSet<K_SNI92HuvudGrupp> K_SNI92HuvudGrupp { get; set; }
        public DbSet<K_SNI92UnderAvdelning> K_SNI92UnderAvdelning { get; set; }
        public DbSet<K_SNI92UnderGrupp> K_SNI92UnderGrupp { get; set; }
        public DbSet<MinTestTabell> MinTestTabells { get; set; }
        public DbSet<S_SNIAnv> S_SNIAnv { get; set; }
        public DbSet<S_SNIAnv2007> S_SNIAnv2007 { get; set; }
        public DbSet<sysdiagram> sysdiagrams { get; set; }
        public DbSet<T_SNI2002Avdelning> T_SNI2002Avdelning { get; set; }
        public DbSet<T_SNI2002DetaljGrupp> T_SNI2002DetaljGrupp { get; set; }
        public DbSet<T_SNI2002Grupp> T_SNI2002Grupp { get; set; }
        public DbSet<T_SNI2002HuvudGrupp> T_SNI2002HuvudGrupp { get; set; }
        public DbSet<T_SNI2002UnderAvdelning> T_SNI2002UnderAvdelning { get; set; }
        public DbSet<T_SNI2002UnderGrupp> T_SNI2002UnderGrupp { get; set; }
        public DbSet<T_SNI2002Uppslag> T_SNI2002Uppslag { get; set; }
        public DbSet<T_SNI2007Avdelning> T_SNI2007Avdelning { get; set; }
        public DbSet<T_SNI2007DetaljGrupp> T_SNI2007DetaljGrupp { get; set; }
        public DbSet<T_SNI2007Grupp> T_SNI2007Grupp { get; set; }
        public DbSet<T_SNI2007HuvudGrupp> T_SNI2007HuvudGrupp { get; set; }
        public DbSet<T_SNI2007UnderGrupp> T_SNI2007UnderGrupp { get; set; }
        public DbSet<T_SNI2007Uppslag> T_SNI2007Uppslag { get; set; }
        public DbSet<T_SNI92_2002_AktArtUtokad_Fast> T_SNI92_2002_AktArtUtokad_Fast { get; set; }
        public DbSet<T_SNI92_2002_UppslagText_Fast> T_SNI92_2002_UppslagText_Fast { get; set; }
        public DbSet<T_UppslagMiss> T_UppslagMiss { get; set; }
        public DbSet<TA_SNI2002Avdelning> TA_SNI2002Avdelning { get; set; }
        public DbSet<TA_SNI2002DetaljGrupp> TA_SNI2002DetaljGrupp { get; set; }
        public DbSet<TA_SNI2002Grupp> TA_SNI2002Grupp { get; set; }
        public DbSet<TA_SNI2002HuvudGrupp> TA_SNI2002HuvudGrupp { get; set; }
        public DbSet<TA_SNI2002UnderAvdelning> TA_SNI2002UnderAvdelning { get; set; }
        public DbSet<TA_SNI2002UnderGrupp> TA_SNI2002UnderGrupp { get; set; }
        public DbSet<TA_SNI2007Avdelning> TA_SNI2007Avdelning { get; set; }
        public DbSet<TA_SNI2007DetaljGrupp> TA_SNI2007DetaljGrupp { get; set; }
        public DbSet<TA_SNI2007Grupp> TA_SNI2007Grupp { get; set; }
        public DbSet<TA_SNI2007HuvudGrupp> TA_SNI2007HuvudGrupp { get; set; }
        public DbSet<TA_SNI2007UnderGrupp> TA_SNI2007UnderGrupp { get; set; }
        public DbSet<vSNI2007Aktivitet> vSNI2007Aktivitet { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AliasSokOrdMap());
            modelBuilder.Configurations.Add(new dtpropertyMap());
            modelBuilder.Configurations.Add(new H_SNI2002AktivitetsArtUtokadMap());
            modelBuilder.Configurations.Add(new H_SNI2007AktivitetsArtUtokadMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002AvdelningMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002DetaljGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002GruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002HuvudGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002UnderAvdelningMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002UnderGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2002UppslagMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new H_T_SNI2007UppslagMap());
            modelBuilder.Configurations.Add(new K_SNI2002AvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI2002AvdelningEngMap());
            modelBuilder.Configurations.Add(new K_SNI2002DetaljGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002DetaljGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2002GruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002GruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2002HuvudGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002HuvudGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2002UnderAvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI2002UnderAvdelningEngMap());
            modelBuilder.Configurations.Add(new K_SNI2002UnderGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2002UnderGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI2007AvdelningEngMap());
            modelBuilder.Configurations.Add(new K_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007DetaljGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007GruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007HuvudGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new K_SNI2007UnderGruppEngMap());
            modelBuilder.Configurations.Add(new K_SNI92AvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI92DetaljGruppMap());
            modelBuilder.Configurations.Add(new K_SNI92GruppMap());
            modelBuilder.Configurations.Add(new K_SNI92HuvudGruppMap());
            modelBuilder.Configurations.Add(new K_SNI92UnderAvdelningMap());
            modelBuilder.Configurations.Add(new K_SNI92UnderGruppMap());
            modelBuilder.Configurations.Add(new MinTestTabellMap());
            modelBuilder.Configurations.Add(new S_SNIAnvMap());
            modelBuilder.Configurations.Add(new S_SNIAnv2007Map());
            modelBuilder.Configurations.Add(new sysdiagramMap());
            modelBuilder.Configurations.Add(new T_SNI2002AvdelningMap());
            modelBuilder.Configurations.Add(new T_SNI2002DetaljGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2002GruppMap());
            modelBuilder.Configurations.Add(new T_SNI2002HuvudGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2002UnderAvdelningMap());
            modelBuilder.Configurations.Add(new T_SNI2002UnderGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2002UppslagMap());
            modelBuilder.Configurations.Add(new T_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new T_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new T_SNI2007UppslagMap());
            modelBuilder.Configurations.Add(new T_SNI92_2002_AktArtUtokad_FastMap());
            modelBuilder.Configurations.Add(new T_SNI92_2002_UppslagText_FastMap());
            modelBuilder.Configurations.Add(new T_UppslagMissMap());
            modelBuilder.Configurations.Add(new TA_SNI2002AvdelningMap());
            modelBuilder.Configurations.Add(new TA_SNI2002DetaljGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2002GruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2002HuvudGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2002UnderAvdelningMap());
            modelBuilder.Configurations.Add(new TA_SNI2002UnderGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007AvdelningMap());
            modelBuilder.Configurations.Add(new TA_SNI2007DetaljGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007GruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007HuvudGruppMap());
            modelBuilder.Configurations.Add(new TA_SNI2007UnderGruppMap());
            modelBuilder.Configurations.Add(new vSNI2007AktivitetMap());
        }
    }
}
