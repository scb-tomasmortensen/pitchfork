using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007AvdelningEng
    {
        public K_SNI2007AvdelningEng()
        {
            this.K_SNI2007HuvudGruppEng = new List<K_SNI2007HuvudGruppEng>();
        }

        public string SNI2007Avdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public virtual ICollection<K_SNI2007HuvudGruppEng> K_SNI2007HuvudGruppEng { get; set; }
    }
}
