using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class TA_SNI2002HuvudGruppMap : EntityTypeConfiguration<TA_SNI2002HuvudGrupp>
    {
        public TA_SNI2002HuvudGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002HuvudGrupp);

            // Properties
            this.Property(t => t.SNI2002HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2002HuvudGrupp");
            this.Property(t => t.SNI2002HuvudGrupp).HasColumnName("SNI2002HuvudGrupp");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002HuvudGrupp)
                .WithOptional(t => t.TA_SNI2002HuvudGrupp);

        }
    }
}
