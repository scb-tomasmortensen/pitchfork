using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2002UnderAvdelningMap : EntityTypeConfiguration<K_SNI2002UnderAvdelning>
    {
        public K_SNI2002UnderAvdelningMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002UnderAvdelning);

            // Properties
            this.Property(t => t.SNI2002UnderAvdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("K_SNI2002UnderAvdelning");
            this.Property(t => t.SNI2002UnderAvdelning).HasColumnName("SNI2002UnderAvdelning");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002Avdelning).HasColumnName("SNI2002Avdelning");

            // Relationships
            this.HasRequired(t => t.K_SNI2002Avdelning)
                .WithMany(t => t.K_SNI2002UnderAvdelning)
                .HasForeignKey(d => d.SNI2002Avdelning);

        }
    }
}
