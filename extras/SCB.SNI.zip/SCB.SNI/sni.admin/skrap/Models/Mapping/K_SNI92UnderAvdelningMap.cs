using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI92UnderAvdelningMap : EntityTypeConfiguration<K_SNI92UnderAvdelning>
    {
        public K_SNI92UnderAvdelningMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI92UnderAvdelning);

            // Properties
            this.Property(t => t.SNI92UnderAvdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI92Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("K_SNI92UnderAvdelning");
            this.Property(t => t.SNI92UnderAvdelning).HasColumnName("SNI92UnderAvdelning");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI92Avdelning).HasColumnName("SNI92Avdelning");

            // Relationships
            this.HasRequired(t => t.K_SNI92Avdelning)
                .WithMany(t => t.K_SNI92UnderAvdelning)
                .HasForeignKey(d => d.SNI92Avdelning);

        }
    }
}
