using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class T_SNI2002AvdelningMap : EntityTypeConfiguration<T_SNI2002Avdelning>
    {
        public T_SNI2002AvdelningMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2002Avdelning, t.OmfTyp, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2002Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("T_SNI2002Avdelning");
            this.Property(t => t.SNI2002Avdelning).HasColumnName("SNI2002Avdelning");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002Avdelning)
                .WithMany(t => t.T_SNI2002Avdelning)
                .HasForeignKey(d => d.SNI2002Avdelning);

        }
    }
}
