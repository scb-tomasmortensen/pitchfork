using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class H_T_SNI2007UppslagMap : EntityTypeConfiguration<H_T_SNI2007Uppslag>
    {
        public H_T_SNI2007UppslagMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007DetaljGrupp, t.OrdNr, t.StartDat, t.SlutDat });

            // Properties
            this.Property(t => t.SNI2007DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.UppslagText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("H_T_SNI2007Uppslag");
            this.Property(t => t.SNI2007DetaljGrupp).HasColumnName("SNI2007DetaljGrupp");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.StartDat).HasColumnName("StartDat");
            this.Property(t => t.SlutDat).HasColumnName("SlutDat");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UppslagKod).HasColumnName("UppslagKod");
            this.Property(t => t.UppslagText).HasColumnName("UppslagText");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007DetaljGrupp)
                .WithMany(t => t.H_T_SNI2007Uppslag)
                .HasForeignKey(d => d.SNI2007DetaljGrupp);

        }
    }
}
