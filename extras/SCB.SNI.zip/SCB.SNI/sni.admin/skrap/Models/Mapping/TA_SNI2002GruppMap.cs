using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class TA_SNI2002GruppMap : EntityTypeConfiguration<TA_SNI2002Grupp>
    {
        public TA_SNI2002GruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002Grupp);

            // Properties
            this.Property(t => t.SNI2002Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2002Grupp");
            this.Property(t => t.SNI2002Grupp).HasColumnName("SNI2002Grupp");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002Grupp)
                .WithOptional(t => t.TA_SNI2002Grupp);

        }
    }
}
