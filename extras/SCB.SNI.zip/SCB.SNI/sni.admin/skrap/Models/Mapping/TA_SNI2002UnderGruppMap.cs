using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class TA_SNI2002UnderGruppMap : EntityTypeConfiguration<TA_SNI2002UnderGrupp>
    {
        public TA_SNI2002UnderGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002UnderGrupp);

            // Properties
            this.Property(t => t.SNI2002UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2002UnderGrupp");
            this.Property(t => t.SNI2002UnderGrupp).HasColumnName("SNI2002UnderGrupp");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002UnderGrupp)
                .WithOptional(t => t.TA_SNI2002UnderGrupp);

        }
    }
}
