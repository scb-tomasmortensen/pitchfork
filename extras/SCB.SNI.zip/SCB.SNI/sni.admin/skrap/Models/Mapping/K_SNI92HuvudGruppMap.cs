using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI92HuvudGruppMap : EntityTypeConfiguration<K_SNI92HuvudGrupp>
    {
        public K_SNI92HuvudGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI92HuvudGrupp);

            // Properties
            this.Property(t => t.SNI92HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI92UnderAvdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            // Table & Column Mappings
            this.ToTable("K_SNI92HuvudGrupp");
            this.Property(t => t.SNI92HuvudGrupp).HasColumnName("SNI92HuvudGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI92UnderAvdelning).HasColumnName("SNI92UnderAvdelning");

            // Relationships
            this.HasRequired(t => t.K_SNI92UnderAvdelning)
                .WithMany(t => t.K_SNI92HuvudGrupp)
                .HasForeignKey(d => d.SNI92UnderAvdelning);

        }
    }
}
