using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class H_SNI2007AktivitetsArtUtokadMap : EntityTypeConfiguration<H_SNI2007AktivitetsArtUtokad>
    {
        public H_SNI2007AktivitetsArtUtokadMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007DetaljGrupp, t.SlutDatum });

            // Properties
            this.Property(t => t.SNI2007DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("H_SNI2007AktivitetsArtUtokad");
            this.Property(t => t.SNI2007DetaljGrupp).HasColumnName("SNI2007DetaljGrupp");
            this.Property(t => t.SlutDatum).HasColumnName("SlutDatum");
            this.Property(t => t.AktivitetsArtUtokad).HasColumnName("AktivitetsArtUtokad");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007DetaljGrupp)
                .WithMany(t => t.H_SNI2007AktivitetsArtUtokad)
                .HasForeignKey(d => d.SNI2007DetaljGrupp);

        }
    }
}
