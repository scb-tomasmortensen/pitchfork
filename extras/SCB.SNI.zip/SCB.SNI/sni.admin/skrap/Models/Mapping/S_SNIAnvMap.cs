using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class S_SNIAnvMap : EntityTypeConfiguration<S_SNIAnv>
    {
        public S_SNIAnvMap()
        {
            // Primary Key
            this.HasKey(t => new { t.UserId, t.SNI2002 });

            // Properties
            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.SNI2002)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            // Table & Column Mappings
            this.ToTable("S_SNIAnv");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.SNI2002).HasColumnName("SNI2002");
        }
    }
}
