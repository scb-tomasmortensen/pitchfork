using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class H_T_SNI2002AvdelningMap : EntityTypeConfiguration<H_T_SNI2002Avdelning>
    {
        public H_T_SNI2002AvdelningMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2002Avdelning, t.OmfTyp, t.StartDat, t.SlutDat, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2002Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("H_T_SNI2002Avdelning");
            this.Property(t => t.SNI2002Avdelning).HasColumnName("SNI2002Avdelning");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.StartDat).HasColumnName("StartDat");
            this.Property(t => t.SlutDat).HasColumnName("SlutDat");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002Avdelning)
                .WithMany(t => t.H_T_SNI2002Avdelning)
                .HasForeignKey(d => d.SNI2002Avdelning);

        }
    }
}
