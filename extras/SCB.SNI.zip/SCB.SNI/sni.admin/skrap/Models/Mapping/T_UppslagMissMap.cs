using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class T_UppslagMissMap : EntityTypeConfiguration<T_UppslagMiss>
    {
        public T_UppslagMissMap()
        {
            // Primary Key
            this.HasKey(t => new { t.UppslagMiss, t.Datum });

            // Properties
            this.Property(t => t.UppslagMiss)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("T_UppslagMiss");
            this.Property(t => t.UppslagMiss).HasColumnName("UppslagMiss");
            this.Property(t => t.Datum).HasColumnName("Datum");
        }
    }
}
