using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2002DetaljGruppEngMap : EntityTypeConfiguration<K_SNI2002DetaljGruppEng>
    {
        public K_SNI2002DetaljGruppEngMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002DetaljGrupp);

            // Properties
            this.Property(t => t.SNI2002DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("K_SNI2002DetaljGruppEng");
            this.Property(t => t.SNI2002DetaljGrupp).HasColumnName("SNI2002DetaljGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002UnderGrupp).HasColumnName("SNI2002UnderGrupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2002UnderGruppEng)
                .WithMany(t => t.K_SNI2002DetaljGruppEng)
                .HasForeignKey(d => d.SNI2002UnderGrupp);

        }
    }
}
