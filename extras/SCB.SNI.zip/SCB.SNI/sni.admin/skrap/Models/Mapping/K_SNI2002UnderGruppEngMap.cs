using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2002UnderGruppEngMap : EntityTypeConfiguration<K_SNI2002UnderGruppEng>
    {
        public K_SNI2002UnderGruppEngMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002UnderGrupp);

            // Properties
            this.Property(t => t.SNI2002UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            // Table & Column Mappings
            this.ToTable("K_SNI2002UnderGruppEng");
            this.Property(t => t.SNI2002UnderGrupp).HasColumnName("SNI2002UnderGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002Grupp).HasColumnName("SNI2002Grupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2002GruppEng)
                .WithMany(t => t.K_SNI2002UnderGruppEng)
                .HasForeignKey(d => d.SNI2002Grupp);

        }
    }
}
