using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI92AvdelningMap : EntityTypeConfiguration<K_SNI92Avdelning>
    {
        public K_SNI92AvdelningMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI92Avdelning);

            // Properties
            this.Property(t => t.SNI92Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("K_SNI92Avdelning");
            this.Property(t => t.SNI92Avdelning).HasColumnName("SNI92Avdelning");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
        }
    }
}
