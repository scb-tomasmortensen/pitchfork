using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI92DetaljGruppMap : EntityTypeConfiguration<K_SNI92DetaljGrupp>
    {
        public K_SNI92DetaljGruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI92DetaljGrupp);

            // Properties
            this.Property(t => t.SNI92DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.AktivitetsArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI92UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("K_SNI92DetaljGrupp");
            this.Property(t => t.SNI92DetaljGrupp).HasColumnName("SNI92DetaljGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.AktivitetsArtUtokad).HasColumnName("AktivitetsArtUtokad");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI92UnderGrupp).HasColumnName("SNI92UnderGrupp");

            // Relationships
            this.HasRequired(t => t.K_SNI92UnderGrupp)
                .WithMany(t => t.K_SNI92DetaljGrupp)
                .HasForeignKey(d => d.SNI92UnderGrupp);

        }
    }
}
