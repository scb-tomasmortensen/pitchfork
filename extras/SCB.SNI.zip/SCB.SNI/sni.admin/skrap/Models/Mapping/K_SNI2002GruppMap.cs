using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2002GruppMap : EntityTypeConfiguration<K_SNI2002Grupp>
    {
        public K_SNI2002GruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002Grupp);

            // Properties
            this.Property(t => t.SNI2002Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            // Table & Column Mappings
            this.ToTable("K_SNI2002Grupp");
            this.Property(t => t.SNI2002Grupp).HasColumnName("SNI2002Grupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002HuvudGrupp).HasColumnName("SNI2002HuvudGrupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2002HuvudGrupp)
                .WithMany(t => t.K_SNI2002Grupp)
                .HasForeignKey(d => d.SNI2002HuvudGrupp);

        }
    }
}
