using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class T_SNI2007UppslagMap : EntityTypeConfiguration<T_SNI2007Uppslag>
    {
        public T_SNI2007UppslagMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007DetaljGrupp, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2007DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.UppslagText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.SNIxxxx)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            // Table & Column Mappings
            this.ToTable("T_SNI2007Uppslag");
            this.Property(t => t.SNI2007DetaljGrupp).HasColumnName("SNI2007DetaljGrupp");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UppslagKod).HasColumnName("UppslagKod");
            this.Property(t => t.UppslagText).HasColumnName("UppslagText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.SNIxxxx).HasColumnName("SNIxxxx");

            // Relationships
            this.HasRequired(t => t.K_SNI2002DetaljGrupp)
                .WithMany(t => t.T_SNI2007Uppslag)
                .HasForeignKey(d => d.SNIxxxx);
            this.HasRequired(t => t.K_SNI2007DetaljGrupp)
                .WithMany(t => t.T_SNI2007Uppslag)
                .HasForeignKey(d => d.SNI2007DetaljGrupp);

        }
    }
}
