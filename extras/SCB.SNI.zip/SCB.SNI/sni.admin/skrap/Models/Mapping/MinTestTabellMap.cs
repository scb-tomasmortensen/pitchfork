using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class MinTestTabellMap : EntityTypeConfiguration<MinTestTabell>
    {
        public MinTestTabellMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2007Avdelning, t.AllmanText, t.BearbDat, t.UserId });

            // Properties
            this.Property(t => t.SNI2007Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("MinTestTabell");
            this.Property(t => t.SNI2007Avdelning).HasColumnName("SNI2007Avdelning");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");
        }
    }
}
