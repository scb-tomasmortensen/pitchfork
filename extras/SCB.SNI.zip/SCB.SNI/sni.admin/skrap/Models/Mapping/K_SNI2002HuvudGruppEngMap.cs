using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2002HuvudGruppEngMap : EntityTypeConfiguration<K_SNI2002HuvudGruppEng>
    {
        public K_SNI2002HuvudGruppEngMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2002HuvudGrupp);

            // Properties
            this.Property(t => t.SNI2002HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002UnderAvdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            // Table & Column Mappings
            this.ToTable("K_SNI2002HuvudGruppEng");
            this.Property(t => t.SNI2002HuvudGrupp).HasColumnName("SNI2002HuvudGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2002UnderAvdelning).HasColumnName("SNI2002UnderAvdelning");

            // Relationships
            this.HasRequired(t => t.K_SNI2002UnderAvdelningEng)
                .WithMany(t => t.K_SNI2002HuvudGruppEng)
                .HasForeignKey(d => d.SNI2002UnderAvdelning);

        }
    }
}
