using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class vSNI2007AktivitetMap : EntityTypeConfiguration<vSNI2007Aktivitet>
    {
        public vSNI2007AktivitetMap()
        {
            // Primary Key
            this.HasKey(t => new { t.Avdelning, t.Akt, t.HuvudGrupp, t.Akt2, t.Grupp, t.Akt3, t.UnderGrupp, t.Akt4, t.Detaljgrupp, t.Akt5 });

            // Properties
            this.Property(t => t.Avdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.Akt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.HuvudGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.Akt2)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.Akt3)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.Akt4)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Detaljgrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.Akt5)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("vSNI2007Aktivitet");
            this.Property(t => t.Avdelning).HasColumnName("Avdelning");
            this.Property(t => t.Akt).HasColumnName("Akt");
            this.Property(t => t.HuvudGrupp).HasColumnName("HuvudGrupp");
            this.Property(t => t.Akt2).HasColumnName("Akt2");
            this.Property(t => t.Grupp).HasColumnName("Grupp");
            this.Property(t => t.Akt3).HasColumnName("Akt3");
            this.Property(t => t.UnderGrupp).HasColumnName("UnderGrupp");
            this.Property(t => t.Akt4).HasColumnName("Akt4");
            this.Property(t => t.Detaljgrupp).HasColumnName("Detaljgrupp");
            this.Property(t => t.Akt5).HasColumnName("Akt5");
        }
    }
}
