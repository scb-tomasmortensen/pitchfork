using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class TA_SNI2007GruppMap : EntityTypeConfiguration<TA_SNI2007Grupp>
    {
        public TA_SNI2007GruppMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007Grupp);

            // Properties
            this.Property(t => t.SNI2007Grupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.AllmanText)
                .IsRequired();

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("TA_SNI2007Grupp");
            this.Property(t => t.SNI2007Grupp).HasColumnName("SNI2007Grupp");
            this.Property(t => t.AllmanText).HasColumnName("AllmanText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2007Grupp)
                .WithOptional(t => t.TA_SNI2007Grupp);

        }
    }
}
