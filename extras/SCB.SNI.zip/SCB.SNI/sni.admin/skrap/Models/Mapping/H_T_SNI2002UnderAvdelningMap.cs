using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class H_T_SNI2002UnderAvdelningMap : EntityTypeConfiguration<H_T_SNI2002UnderAvdelning>
    {
        public H_T_SNI2002UnderAvdelningMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2002UnderAvdelning, t.OmfTyp, t.StartDat, t.SlutDat, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2002UnderAvdelning)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("H_T_SNI2002UnderAvdelning");
            this.Property(t => t.SNI2002UnderAvdelning).HasColumnName("SNI2002UnderAvdelning");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.StartDat).HasColumnName("StartDat");
            this.Property(t => t.SlutDat).HasColumnName("SlutDat");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002UnderAvdelning)
                .WithMany(t => t.H_T_SNI2002UnderAvdelning)
                .HasForeignKey(d => d.SNI2002UnderAvdelning);

        }
    }
}
