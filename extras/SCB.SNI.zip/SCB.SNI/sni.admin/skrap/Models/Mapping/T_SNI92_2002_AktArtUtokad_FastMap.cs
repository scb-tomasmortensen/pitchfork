using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class T_SNI92_2002_AktArtUtokad_FastMap : EntityTypeConfiguration<T_SNI92_2002_AktArtUtokad_Fast>
    {
        public T_SNI92_2002_AktArtUtokad_FastMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI92DetaljGrupp, t.SNI2002DetaljGrupp });

            // Properties
            this.Property(t => t.SNI92DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.SNI2002DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.SNI92AktArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2002AktArtUtokad)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("T_SNI92_2002_AktArtUtokad_Fast");
            this.Property(t => t.SNI92DetaljGrupp).HasColumnName("SNI92DetaljGrupp");
            this.Property(t => t.SNI2002DetaljGrupp).HasColumnName("SNI2002DetaljGrupp");
            this.Property(t => t.SNI92AktArtUtokad).HasColumnName("SNI92AktArtUtokad");
            this.Property(t => t.SNI2002AktArtUtokad).HasColumnName("SNI2002AktArtUtokad");
        }
    }
}
