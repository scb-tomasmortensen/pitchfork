using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class T_SNI2002DetaljGruppMap : EntityTypeConfiguration<T_SNI2002DetaljGrupp>
    {
        public T_SNI2002DetaljGruppMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SNI2002DetaljGrupp, t.OmfTyp, t.OrdNr });

            // Properties
            this.Property(t => t.SNI2002DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.OrdNr)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.DelText)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("T_SNI2002DetaljGrupp");
            this.Property(t => t.SNI2002DetaljGrupp).HasColumnName("SNI2002DetaljGrupp");
            this.Property(t => t.OmfTyp).HasColumnName("OmfTyp");
            this.Property(t => t.OrdNr).HasColumnName("OrdNr");
            this.Property(t => t.DelText).HasColumnName("DelText");
            this.Property(t => t.BearbDat).HasColumnName("BearbDat");
            this.Property(t => t.RedigeringKod).HasColumnName("RedigeringKod");
            this.Property(t => t.UserId).HasColumnName("UserId");

            // Relationships
            this.HasRequired(t => t.K_SNI2002DetaljGrupp)
                .WithMany(t => t.T_SNI2002DetaljGrupp)
                .HasForeignKey(d => d.SNI2002DetaljGrupp);

        }
    }
}
