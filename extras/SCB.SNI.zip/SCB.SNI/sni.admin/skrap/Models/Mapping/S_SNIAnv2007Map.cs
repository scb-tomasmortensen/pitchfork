using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class S_SNIAnv2007Map : EntityTypeConfiguration<S_SNIAnv2007>
    {
        public S_SNIAnv2007Map()
        {
            // Primary Key
            this.HasKey(t => new { t.UserId, t.SNI2007 });

            // Properties
            this.Property(t => t.UserId)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.SNI2007)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            // Table & Column Mappings
            this.ToTable("S_SNIAnv2007");
            this.Property(t => t.UserId).HasColumnName("UserId");
            this.Property(t => t.SNI2007).HasColumnName("SNI2007");
        }
    }
}
