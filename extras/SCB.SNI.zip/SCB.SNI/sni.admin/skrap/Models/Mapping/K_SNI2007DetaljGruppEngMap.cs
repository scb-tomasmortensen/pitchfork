using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace skrap.Models.Mapping
{
    public class K_SNI2007DetaljGruppEngMap : EntityTypeConfiguration<K_SNI2007DetaljGruppEng>
    {
        public K_SNI2007DetaljGruppEngMap()
        {
            // Primary Key
            this.HasKey(t => t.SNI2007DetaljGrupp);

            // Properties
            this.Property(t => t.SNI2007DetaljGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.AktivitetsArt)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Bransch)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SNI2007UnderGrupp)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("K_SNI2007DetaljGruppEng");
            this.Property(t => t.SNI2007DetaljGrupp).HasColumnName("SNI2007DetaljGrupp");
            this.Property(t => t.AktivitetsArt).HasColumnName("AktivitetsArt");
            this.Property(t => t.Bransch).HasColumnName("Bransch");
            this.Property(t => t.SNI2007UnderGrupp).HasColumnName("SNI2007UnderGrupp");

            // Relationships
            this.HasRequired(t => t.K_SNI2007UnderGruppEng)
                .WithMany(t => t.K_SNI2007DetaljGruppEng)
                .HasForeignKey(d => d.SNI2007UnderGrupp);

        }
    }
}
