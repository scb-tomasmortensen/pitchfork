using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class S_SNIAnv
    {
        public string UserId { get; set; }
        public string SNI2002 { get; set; }
    }
}
