using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class TA_SNI2002HuvudGrupp
    {
        public string SNI2002HuvudGrupp { get; set; }
        public string AllmanText { get; set; }
        public System.DateTime BearbDat { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2002HuvudGrupp K_SNI2002HuvudGrupp { get; set; }
    }
}
