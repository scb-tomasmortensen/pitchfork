using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class AliasSokOrd
    {
        public string AliasSokOrd1 { get; set; }
        public string SokOrd { get; set; }
    }
}
