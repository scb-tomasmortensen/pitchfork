using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92HuvudGrupp
    {
        public K_SNI92HuvudGrupp()
        {
            this.K_SNI92Grupp = new List<K_SNI92Grupp>();
        }

        public string SNI92HuvudGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI92UnderAvdelning { get; set; }
        public virtual ICollection<K_SNI92Grupp> K_SNI92Grupp { get; set; }
        public virtual K_SNI92UnderAvdelning K_SNI92UnderAvdelning { get; set; }
    }
}
