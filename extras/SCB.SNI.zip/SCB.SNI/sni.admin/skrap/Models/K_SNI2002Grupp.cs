using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002Grupp
    {
        public K_SNI2002Grupp()
        {
            this.H_T_SNI2002Grupp = new List<H_T_SNI2002Grupp>();
            this.K_SNI2002UnderGrupp = new List<K_SNI2002UnderGrupp>();
            this.T_SNI2002Grupp = new List<T_SNI2002Grupp>();
        }

        public string SNI2002Grupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002HuvudGrupp { get; set; }
        public virtual ICollection<H_T_SNI2002Grupp> H_T_SNI2002Grupp { get; set; }
        public virtual K_SNI2002HuvudGrupp K_SNI2002HuvudGrupp { get; set; }
        public virtual ICollection<K_SNI2002UnderGrupp> K_SNI2002UnderGrupp { get; set; }
        public virtual ICollection<T_SNI2002Grupp> T_SNI2002Grupp { get; set; }
        public virtual TA_SNI2002Grupp TA_SNI2002Grupp { get; set; }
    }
}
