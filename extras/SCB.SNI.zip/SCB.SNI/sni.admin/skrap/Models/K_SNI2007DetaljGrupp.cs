using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007DetaljGrupp
    {
        public K_SNI2007DetaljGrupp()
        {
            this.H_SNI2007AktivitetsArtUtokad = new List<H_SNI2007AktivitetsArtUtokad>();
            this.H_T_SNI2007DetaljGrupp = new List<H_T_SNI2007DetaljGrupp>();
            this.H_T_SNI2007Uppslag = new List<H_T_SNI2007Uppslag>();
            this.T_SNI2007DetaljGrupp = new List<T_SNI2007DetaljGrupp>();
            this.T_SNI2007Uppslag = new List<T_SNI2007Uppslag>();
            this.T_SNI2002Uppslag = new List<T_SNI2002Uppslag>();
            this.K_SNI2002DetaljGrupp = new List<K_SNI2002DetaljGrupp>();
        }

        public string SNI2007DetaljGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string Bransch { get; set; }
        public string SNI2007UnderGrupp { get; set; }
        public virtual ICollection<H_SNI2007AktivitetsArtUtokad> H_SNI2007AktivitetsArtUtokad { get; set; }
        public virtual ICollection<H_T_SNI2007DetaljGrupp> H_T_SNI2007DetaljGrupp { get; set; }
        public virtual ICollection<H_T_SNI2007Uppslag> H_T_SNI2007Uppslag { get; set; }
        public virtual K_SNI2007UnderGrupp K_SNI2007UnderGrupp { get; set; }
        public virtual ICollection<T_SNI2007DetaljGrupp> T_SNI2007DetaljGrupp { get; set; }
        public virtual ICollection<T_SNI2007Uppslag> T_SNI2007Uppslag { get; set; }
        public virtual ICollection<T_SNI2002Uppslag> T_SNI2002Uppslag { get; set; }
        public virtual TA_SNI2007DetaljGrupp TA_SNI2007DetaljGrupp { get; set; }
        public virtual ICollection<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupp { get; set; }
    }
}
