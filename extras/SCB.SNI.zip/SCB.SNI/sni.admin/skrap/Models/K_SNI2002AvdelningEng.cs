using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002AvdelningEng
    {
        public K_SNI2002AvdelningEng()
        {
            this.K_SNI2002UnderAvdelningEng = new List<K_SNI2002UnderAvdelningEng>();
        }

        public string SNI2002Avdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public virtual ICollection<K_SNI2002UnderAvdelningEng> K_SNI2002UnderAvdelningEng { get; set; }
    }
}
