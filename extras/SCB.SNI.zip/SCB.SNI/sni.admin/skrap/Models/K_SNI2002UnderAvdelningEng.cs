using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002UnderAvdelningEng
    {
        public K_SNI2002UnderAvdelningEng()
        {
            this.K_SNI2002HuvudGruppEng = new List<K_SNI2002HuvudGruppEng>();
        }

        public string SNI2002UnderAvdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002Avdelning { get; set; }
        public virtual K_SNI2002AvdelningEng K_SNI2002AvdelningEng { get; set; }
        public virtual ICollection<K_SNI2002HuvudGruppEng> K_SNI2002HuvudGruppEng { get; set; }
    }
}
