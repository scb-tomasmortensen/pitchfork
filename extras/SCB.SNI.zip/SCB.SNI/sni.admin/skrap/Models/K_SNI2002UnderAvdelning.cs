using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002UnderAvdelning
    {
        public K_SNI2002UnderAvdelning()
        {
            this.H_T_SNI2002UnderAvdelning = new List<H_T_SNI2002UnderAvdelning>();
            this.K_SNI2002HuvudGrupp = new List<K_SNI2002HuvudGrupp>();
            this.T_SNI2002UnderAvdelning = new List<T_SNI2002UnderAvdelning>();
        }

        public string SNI2002UnderAvdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002Avdelning { get; set; }
        public virtual ICollection<H_T_SNI2002UnderAvdelning> H_T_SNI2002UnderAvdelning { get; set; }
        public virtual K_SNI2002Avdelning K_SNI2002Avdelning { get; set; }
        public virtual ICollection<K_SNI2002HuvudGrupp> K_SNI2002HuvudGrupp { get; set; }
        public virtual ICollection<T_SNI2002UnderAvdelning> T_SNI2002UnderAvdelning { get; set; }
        public virtual TA_SNI2002UnderAvdelning TA_SNI2002UnderAvdelning { get; set; }
    }
}
