using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002HuvudGruppEng
    {
        public K_SNI2002HuvudGruppEng()
        {
            this.K_SNI2002GruppEng = new List<K_SNI2002GruppEng>();
        }

        public string SNI2002HuvudGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002UnderAvdelning { get; set; }
        public virtual ICollection<K_SNI2002GruppEng> K_SNI2002GruppEng { get; set; }
        public virtual K_SNI2002UnderAvdelningEng K_SNI2002UnderAvdelningEng { get; set; }
    }
}
