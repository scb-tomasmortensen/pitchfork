using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92DetaljGrupp
    {
        public K_SNI92DetaljGrupp()
        {
            this.K_SNI2002DetaljGrupp = new List<K_SNI2002DetaljGrupp>();
        }

        public string SNI92DetaljGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string Bransch { get; set; }
        public string SNI92UnderGrupp { get; set; }
        public virtual K_SNI92UnderGrupp K_SNI92UnderGrupp { get; set; }
        public virtual ICollection<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupp { get; set; }
    }
}
