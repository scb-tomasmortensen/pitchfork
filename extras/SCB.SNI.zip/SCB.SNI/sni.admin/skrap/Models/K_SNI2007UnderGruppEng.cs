using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007UnderGruppEng
    {
        public K_SNI2007UnderGruppEng()
        {
            this.K_SNI2007DetaljGruppEng = new List<K_SNI2007DetaljGruppEng>();
        }

        public string SNI2007UnderGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2007Grupp { get; set; }
        public virtual ICollection<K_SNI2007DetaljGruppEng> K_SNI2007DetaljGruppEng { get; set; }
        public virtual K_SNI2007GruppEng K_SNI2007GruppEng { get; set; }
    }
}
