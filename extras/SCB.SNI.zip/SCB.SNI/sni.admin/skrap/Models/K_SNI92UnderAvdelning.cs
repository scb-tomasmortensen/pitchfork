using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92UnderAvdelning
    {
        public K_SNI92UnderAvdelning()
        {
            this.K_SNI92HuvudGrupp = new List<K_SNI92HuvudGrupp>();
        }

        public string SNI92UnderAvdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI92Avdelning { get; set; }
        public virtual K_SNI92Avdelning K_SNI92Avdelning { get; set; }
        public virtual ICollection<K_SNI92HuvudGrupp> K_SNI92HuvudGrupp { get; set; }
    }
}
