using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002UnderGrupp
    {
        public K_SNI2002UnderGrupp()
        {
            this.H_T_SNI2002UnderGrupp = new List<H_T_SNI2002UnderGrupp>();
            this.K_SNI2002DetaljGrupp = new List<K_SNI2002DetaljGrupp>();
            this.T_SNI2002UnderGrupp = new List<T_SNI2002UnderGrupp>();
        }

        public string SNI2002UnderGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002Grupp { get; set; }
        public virtual ICollection<H_T_SNI2002UnderGrupp> H_T_SNI2002UnderGrupp { get; set; }
        public virtual ICollection<K_SNI2002DetaljGrupp> K_SNI2002DetaljGrupp { get; set; }
        public virtual K_SNI2002Grupp K_SNI2002Grupp { get; set; }
        public virtual ICollection<T_SNI2002UnderGrupp> T_SNI2002UnderGrupp { get; set; }
        public virtual TA_SNI2002UnderGrupp TA_SNI2002UnderGrupp { get; set; }
    }
}
