using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002Avdelning
    {
        public K_SNI2002Avdelning()
        {
            this.H_T_SNI2002Avdelning = new List<H_T_SNI2002Avdelning>();
            this.K_SNI2002UnderAvdelning = new List<K_SNI2002UnderAvdelning>();
            this.T_SNI2002Avdelning = new List<T_SNI2002Avdelning>();
        }

        public string SNI2002Avdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public virtual ICollection<H_T_SNI2002Avdelning> H_T_SNI2002Avdelning { get; set; }
        public virtual ICollection<K_SNI2002UnderAvdelning> K_SNI2002UnderAvdelning { get; set; }
        public virtual ICollection<T_SNI2002Avdelning> T_SNI2002Avdelning { get; set; }
        public virtual TA_SNI2002Avdelning TA_SNI2002Avdelning { get; set; }
    }
}
