using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2007Avdelning
    {
        public K_SNI2007Avdelning()
        {
            this.H_T_SNI2007Avdelning = new List<H_T_SNI2007Avdelning>();
            this.K_SNI2007HuvudGrupp = new List<K_SNI2007HuvudGrupp>();
            this.T_SNI2007Avdelning = new List<T_SNI2007Avdelning>();
        }

        public string SNI2007Avdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public virtual ICollection<H_T_SNI2007Avdelning> H_T_SNI2007Avdelning { get; set; }
        public virtual ICollection<K_SNI2007HuvudGrupp> K_SNI2007HuvudGrupp { get; set; }
        public virtual ICollection<T_SNI2007Avdelning> T_SNI2007Avdelning { get; set; }
        public virtual TA_SNI2007Avdelning TA_SNI2007Avdelning { get; set; }
    }
}
