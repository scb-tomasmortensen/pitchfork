using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class H_SNI2002AktivitetsArtUtokad
    {
        public string SNI2002DetaljGrupp { get; set; }
        public System.DateTime SlutDatum { get; set; }
        public string AktivitetsArtUtokad { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2002DetaljGrupp K_SNI2002DetaljGrupp { get; set; }
    }
}
