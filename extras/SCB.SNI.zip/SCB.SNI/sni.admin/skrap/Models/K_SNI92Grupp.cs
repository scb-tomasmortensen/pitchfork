using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92Grupp
    {
        public K_SNI92Grupp()
        {
            this.K_SNI92UnderGrupp = new List<K_SNI92UnderGrupp>();
        }

        public string SNI92Grupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI92HuvudGrupp { get; set; }
        public virtual K_SNI92HuvudGrupp K_SNI92HuvudGrupp { get; set; }
        public virtual ICollection<K_SNI92UnderGrupp> K_SNI92UnderGrupp { get; set; }
    }
}
