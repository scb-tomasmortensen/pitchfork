using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002HuvudGrupp
    {
        public K_SNI2002HuvudGrupp()
        {
            this.H_T_SNI2002HuvudGrupp = new List<H_T_SNI2002HuvudGrupp>();
            this.K_SNI2002Grupp = new List<K_SNI2002Grupp>();
            this.T_SNI2002HuvudGrupp = new List<T_SNI2002HuvudGrupp>();
        }

        public string SNI2002HuvudGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002UnderAvdelning { get; set; }
        public virtual ICollection<H_T_SNI2002HuvudGrupp> H_T_SNI2002HuvudGrupp { get; set; }
        public virtual ICollection<K_SNI2002Grupp> K_SNI2002Grupp { get; set; }
        public virtual K_SNI2002UnderAvdelning K_SNI2002UnderAvdelning { get; set; }
        public virtual ICollection<T_SNI2002HuvudGrupp> T_SNI2002HuvudGrupp { get; set; }
        public virtual TA_SNI2002HuvudGrupp TA_SNI2002HuvudGrupp { get; set; }
    }
}
