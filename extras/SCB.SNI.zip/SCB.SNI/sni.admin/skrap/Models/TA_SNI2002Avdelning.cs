using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class TA_SNI2002Avdelning
    {
        public string SNI2002Avdelning { get; set; }
        public string AllmanText { get; set; }
        public System.DateTime BearbDat { get; set; }
        public string UserId { get; set; }
        public virtual K_SNI2002Avdelning K_SNI2002Avdelning { get; set; }
    }
}
