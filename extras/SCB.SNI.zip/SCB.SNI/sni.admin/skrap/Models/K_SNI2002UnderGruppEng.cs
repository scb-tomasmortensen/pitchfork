using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI2002UnderGruppEng
    {
        public K_SNI2002UnderGruppEng()
        {
            this.K_SNI2002DetaljGruppEng = new List<K_SNI2002DetaljGruppEng>();
        }

        public string SNI2002UnderGrupp { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public string SNI2002Grupp { get; set; }
        public virtual ICollection<K_SNI2002DetaljGruppEng> K_SNI2002DetaljGruppEng { get; set; }
        public virtual K_SNI2002GruppEng K_SNI2002GruppEng { get; set; }
    }
}
