using System;
using System.Collections.Generic;

namespace skrap.Models
{
    public partial class K_SNI92Avdelning
    {
        public K_SNI92Avdelning()
        {
            this.K_SNI92UnderAvdelning = new List<K_SNI92UnderAvdelning>();
        }

        public string SNI92Avdelning { get; set; }
        public string AktivitetsArt { get; set; }
        public string Bransch { get; set; }
        public virtual ICollection<K_SNI92UnderAvdelning> K_SNI92UnderAvdelning { get; set; }
    }
}
